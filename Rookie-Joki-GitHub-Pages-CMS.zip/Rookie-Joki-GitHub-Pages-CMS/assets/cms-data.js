// ==========================================================
// ROOKIE JOKI - CMS DEFAULT DATA
// ==========================================================
const DEFAULT_SITE_DATA = {
  "meta": {
    "schemaVersion": 1,
    "adminPhone": "6285266558018"
  },
  "admin": {
    "username": "admin",
    "passwordHash": "4671037693915bc095fb26f7f6a01ea665b38c76c429bfeaf1a3db5f700e712d"
  },
  "header": {
    "title": "Rookie Joki",
    "tagline": "Joki Rank MLBB Termurah Se-Nusantara",
    "ctaLabel": "Pesan",
    "ctaTarget": "#pricelist"
  },
  "ticker": [
    {
      "icon": "shield-check",
      "text": "Terpercaya Sejak 2021",
      "color": "text-brand-accent"
    },
    {
      "icon": "",
      "text": "Joki Rank MLBB Termurah Se-Nusantara!",
      "color": "text-white"
    },
    {
      "icon": "zap",
      "text": "Proses Cepat & Aman 100%",
      "color": "text-emerald-400"
    }
  ],
  "slider": [
    {
      "image": "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=1200&auto=format&fit=crop",
      "badgeText": "PROMO SPESIAL 2026",
      "badgeColor": "bg-brand-blue",
      "title": "Push Rank Cepat & Anti Minus MLBB",
      "desc": "Bergaransi Winrate tinggi bersama Pro Player sejak 2021."
    },
    {
      "image": "https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=1200&auto=format&fit=crop",
      "badgeText": "GARANSI 100%",
      "badgeColor": "bg-amber-500",
      "title": "Jaminan Winrate & Keamanan Akun",
      "desc": "Privasi terjaga, pengerjaan cepat tanpa mengganggu waktu main."
    },
    {
      "image": "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?q=80&w=1200&auto=format&fit=crop",
      "badgeText": "SPECIAL EVENT",
      "badgeColor": "bg-amber-500",
      "title": "Paket Mythic Placement Termurah",
      "desc": "Dapatkan harga khusus paket Mythic Glory & Immortal hari ini."
    }
  ],
  "pricelist": {
    "tabs": [
      {
        "key": "perbintang",
        "label": "Per Bintang"
      },
      {
        "key": "paket",
        "label": "Paket Hemat"
      },
      {
        "key": "gendong",
        "label": "Joki Gendong"
      },
      {
        "key": "mabar",
        "label": "Mabar VIP"
      },
      {
        "key": "mro",
        "label": "MRO Turnamen"
      }
    ],
    "categories": {
      "perbintang": [
        {
          "name": "Warrior",
          "price": "Rp 1.000 / bintang",
          "tag": "Per Bintang",
          "popular": false
        },
        {
          "name": "Elite",
          "price": "Rp 1.500 / bintang",
          "tag": "Per Bintang",
          "popular": false
        },
        {
          "name": "Master",
          "price": "Rp 2.000 / bintang",
          "tag": "Per Bintang",
          "popular": false
        },
        {
          "name": "Grandmaster",
          "price": "Rp 3.000 / bintang",
          "tag": "Per Bintang",
          "popular": false
        },
        {
          "name": "Epic",
          "price": "Rp 4.000 / bintang",
          "tag": "Most Popular",
          "popular": true
        },
        {
          "name": "Legend",
          "price": "Rp 5.000 / bintang",
          "tag": "Per Bintang",
          "popular": false
        },
        {
          "name": "Mythic",
          "price": "Rp 7.000 / bintang",
          "tag": "1 - 25 Star",
          "popular": false
        },
        {
          "name": "Mythical Honor",
          "price": "Rp 10.000 / bintang",
          "tag": "25 - 50 Star",
          "popular": false
        },
        {
          "name": "Mythical Glory",
          "price": "Rp 13.000 / bintang",
          "tag": "50 - 100 Star",
          "popular": false
        },
        {
          "name": "Mythical Immortal",
          "price": "Rp 18.000 / bintang",
          "tag": "100+ Star",
          "popular": false
        }
      ],
      "paket": [
        {
          "name": "Warrior (Full Tier)",
          "price": "Rp 9.000",
          "tag": "Paket Hemat",
          "popular": false
        },
        {
          "name": "Elite (Full Tier)",
          "price": "Rp 18.000",
          "tag": "Paket Hemat",
          "popular": false
        },
        {
          "name": "Master (Full Tier)",
          "price": "Rp 30.000",
          "tag": "Paket Hemat",
          "popular": false
        },
        {
          "name": "Grandmaster (Full Tier)",
          "price": "Rp 60.000",
          "tag": "Paket Hemat",
          "popular": false
        },
        {
          "name": "Epic (Full Tier)",
          "price": "Rp 100.000",
          "tag": "Best Seller",
          "popular": true
        },
        {
          "name": "Legend (Full Tier)",
          "price": "Rp 125.000",
          "tag": "Paket Hemat",
          "popular": false
        },
        {
          "name": "Full Grading Placement",
          "price": "Rp 100.000",
          "tag": "15 Bintang Full Hijau",
          "popular": true
        },
        {
          "name": "Mythic (Placement 1-25 Star)",
          "price": "Rp 175.000",
          "tag": "Paket 25 Star",
          "popular": false
        },
        {
          "name": "Mythical Honor (25-50 Star)",
          "price": "Rp 250.000",
          "tag": "Paket 25 Star",
          "popular": false
        },
        {
          "name": "Mythical Glory (50-100 Star)",
          "price": "Rp 650.000",
          "tag": "Paket 50 Star",
          "popular": false
        },
        {
          "name": "Mythical Immortal (100+ Star)",
          "price": "Hubungi Admin",
          "tag": "Custom Request",
          "popular": false
        }
      ],
      "gendong": [
        {
          "name": "Joki Gendong Warrior",
          "price": "Rp 2.500 / win",
          "tag": "Main Bareng Worker",
          "popular": false
        },
        {
          "name": "Joki Gendong Elite",
          "price": "Rp 3.000 / win",
          "tag": "Main Bareng Worker",
          "popular": false
        },
        {
          "name": "Joki Gendong Master",
          "price": "Rp 4.000 / win",
          "tag": "Main Bareng Worker",
          "popular": false
        },
        {
          "name": "Joki Gendong Grandmaster",
          "price": "Rp 5.000 / win",
          "tag": "Main Bareng Worker",
          "popular": false
        },
        {
          "name": "Joki Gendong Epic",
          "price": "Rp 7.000 / win",
          "tag": "Fast Win Rate",
          "popular": true
        },
        {
          "name": "Joki Gendong Legend",
          "price": "Rp 9.000 / win",
          "tag": "Main Bareng Worker",
          "popular": false
        },
        {
          "name": "Joki Gendong Mythic",
          "price": "Rp 12.000 / win",
          "tag": "Main Bareng Worker",
          "popular": false
        },
        {
          "name": "Joki Gendong Mythical Honor",
          "price": "Rp 15.000 / win",
          "tag": "Main Bareng Worker",
          "popular": false
        },
        {
          "name": "Joki Gendong Mythical Glory",
          "price": "Rp 20.000 / win",
          "tag": "Pro Player Party",
          "popular": false
        },
        {
          "name": "Joki Gendong Mythical Immortal",
          "price": "Rp 30.000 / win",
          "tag": "Top Squad",
          "popular": false
        }
      ],
      "mabar": [
        {
          "name": "Mabar VIP Warrior",
          "price": "Rp 15.000 / jam",
          "tag": "Voice Chat On",
          "popular": false
        },
        {
          "name": "Mabar VIP Elite",
          "price": "Rp 15.000 / jam",
          "tag": "Voice Chat On",
          "popular": false
        },
        {
          "name": "Mabar VIP Master",
          "price": "Rp 20.000 / jam",
          "tag": "Voice Chat On",
          "popular": false
        },
        {
          "name": "Mabar VIP Grandmaster",
          "price": "Rp 25.000 / jam",
          "tag": "Voice Chat On",
          "popular": false
        },
        {
          "name": "Mabar VIP Epic",
          "price": "Rp 30.000 / jam",
          "tag": "Fun & Fast Rank",
          "popular": true
        },
        {
          "name": "Mabar VIP Legend",
          "price": "Rp 40.000 / jam",
          "tag": "Voice Chat On",
          "popular": false
        },
        {
          "name": "Mabar VIP Mythic",
          "price": "Rp 50.000 / jam",
          "tag": "Voice Chat On",
          "popular": false
        },
        {
          "name": "Mabar VIP Mythical Honor",
          "price": "Rp 65.000 / jam",
          "tag": "Pro Teammate",
          "popular": false
        },
        {
          "name": "Mabar VIP Mythical Glory",
          "price": "Rp 85.000 / jam",
          "tag": "High Class Pro",
          "popular": false
        },
        {
          "name": "Mabar VIP Mythical Immortal",
          "price": "Rp 120.000 / jam",
          "tag": "Pro Streamer / Player",
          "popular": false
        }
      ],
      "mro": [
        {
          "name": "Rising Piala Coklat",
          "price": "Rp 25.000 / match",
          "tag": "Turnamen MRO",
          "popular": false
        },
        {
          "name": "Rising Piala Hijau",
          "price": "Rp 35.000 / match",
          "tag": "Bracket Area",
          "popular": false
        },
        {
          "name": "Rising Piala Biru",
          "price": "Rp 50.000 / match",
          "tag": "Bracket Kota",
          "popular": true
        },
        {
          "name": "Rising Piala Ungu",
          "price": "Rp 75.000 / match",
          "tag": "Bracket Provinsi",
          "popular": false
        },
        {
          "name": "Rising Piala Emas",
          "price": "Rp 100.000 / match",
          "tag": "Bracket Subregional",
          "popular": false
        },
        {
          "name": "Rising Piala Merah",
          "price": "Rp 150.000 / match",
          "tag": "Bracket Regional",
          "popular": false
        }
      ]
    }
  },
  "portfolio": [
    {
      "image": "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop",
      "title": "Finish Mythic Glory 85 Star",
      "desc": "Pengerjaan 3 hari tanpa lose streak bersama pro player.",
      "tag": "Mythic Glory",
      "worker": "Worker: Viper",
      "status": "100% Clean"
    },
    {
      "image": "https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=800&auto=format&fit=crop",
      "title": "Paket Kilat Epic ke Legend",
      "desc": "Selesai dalam 1 malam dengan winrate hero core 92%.",
      "tag": "Epic to Legend",
      "worker": "Worker: Kaiser",
      "status": "100% Clean"
    },
    {
      "image": "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?q=80&w=800&auto=format&fit=crop",
      "title": "Sesi Mabar VIP 10 Win Beruntun",
      "desc": "Client main sendiri didampingi top global squad kami.",
      "tag": "Joki Gendong",
      "worker": "Worker: Zeta",
      "status": "Voice Chat On"
    },
    {
      "image": "https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=800&auto=format&fit=crop",
      "title": "Juara 1 Bracket Piala Biru MRO",
      "desc": "Joki turnamen resmi tingkat kota bergaransi aman.",
      "tag": "MRO Turnamen",
      "worker": "Squad Utama",
      "status": "Official Cup"
    },
    {
      "image": "https://images.unsplash.com/photo-1563089145-599997674d42?q=80&w=800&auto=format&fit=crop",
      "title": "Lolos Neraka Draft GM ke Epic",
      "desc": "Selesai kilat dalam beberapa jam dengan hero mage.",
      "tag": "Grandmaster",
      "worker": "Worker: Apex",
      "status": "Fast Process"
    },
    {
      "image": "https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?q=80&w=800&auto=format&fit=crop",
      "title": "Push 25 Bintang Mythic Honor",
      "desc": "Bebas request role hero Jungler / Gold Laner.",
      "tag": "Mythic Honor",
      "worker": "Worker: Shadow",
      "status": "Request Hero"
    },
    {
      "image": "https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?q=80&w=800&auto=format&fit=crop",
      "title": "Fix Winrate Fanny 85%",
      "desc": "Spesialis top local hero buff privat bergaransi.",
      "tag": "Boost WR Hero",
      "worker": "Worker: Hyper",
      "status": "Top Local"
    },
    {
      "image": "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?q=80&w=800&auto=format&fit=crop",
      "title": "10 Game Placement 10 Win",
      "desc": "Hasil bersih tanpa ternoda kekalahan awal season.",
      "tag": "Placement Full Hijau",
      "worker": "Worker: Blitz",
      "status": "10/10 Win"
    },
    {
      "image": "https://images.unsplash.com/photo-1560253023-3ec5d502959f?q=80&w=800&auto=format&fit=crop",
      "title": "Masuk Leaderboard Immortal",
      "desc": "Dikerjakan langsung oleh pro player top global.",
      "tag": "Immortal Tier",
      "worker": "Worker: Alpha",
      "status": "Top Global"
    },
    {
      "image": "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800&auto=format&fit=crop",
      "title": "Paket Party 5 Orang",
      "desc": "Full squad siap gendong akun kamu tanpa takut beban.",
      "tag": "Joki Gendong VIP",
      "worker": "Worker: Team Omega",
      "status": "Full Squad"
    }
  ],
  "aboutUs": {
    "badgeText": "Rookie Joki",
    "subtitle": "Rookie Joki • Sejak 2021",
    "heroTitle": "Bantu capai Rank impian Anda tanpa ribet.",
    "heroText": "Bingung Winrate naik-turun terus, lalu Rank kalian masih stak di Epic/Legend? Sini! Kami siap mengatasi permasalahan seputar Mobile Legends kalian, Kings! Solusi joki Rank Mobile Legends: Bang Bang untuk player yang ingin proses praktis, cepat dan nyaman.",
    "sectionTitle": "Siapa Kami?",
    "paragraph1": "Rookie Joki adalah sebuah layanan yang menyediakan jasa joki Mobile Legends bagi pemain yang ingin meningkatkan peringkat, mencapai level tertentu, atau meraih prestasi dalam permainan. Jasa joki ini melibatkan pemain berpengalaman yang menggunakan akun pelanggan untuk bermain dan membantu mencapai tujuan yang diinginkan. Permintaan untuk jasa ini sangat tinggi, hingga saat ini sudah ratusan akun dari berbagai level telah kami bantu.",
    "paragraph2": "Dalam beberapa tahun terakhir, perkembangan industri game berkembang pesat di berbagai kalangan. Kami berharap dapat terus memenuhi kebutuhan komunitas gamer di Indonesia dan memberikan kemudahan serta kenyamanan dalam bermain game Mobile Legends.",
    "commitments": [
      {
        "icon": "zap",
        "title": "Cepat",
        "desc": "Pengerjaan mengikuti estimasi layanan."
      },
      {
        "icon": "lock-keyhole",
        "title": "Privasi",
        "desc": "Kerahasiaan akun menjadi prioritas."
      },
      {
        "icon": "badge-check",
        "title": "Bergaransi",
        "desc": "Layanan dilengkapi komitmen garansi."
      },
      {
        "icon": "users",
        "title": "Berpengalaman",
        "desc": "Didukung worker berpengalaman."
      }
    ],
    "quickInfo": [
      {
        "label": "Berdiri sejak",
        "value": "2021"
      },
      {
        "label": "Fokus layanan",
        "value": "Rank MLBB"
      },
      {
        "label": "Jangkauan",
        "value": "Se-Nusantara"
      }
    ],
    "ctaTitle": "Butuh bantuan atau ingin pesan?",
    "ctaText": "Pilih paket layanan atau hubungi admin Rookie Joki melalui WhatsApp."
  },
  "disclaimer": {
    "intro": "Mohon baca ketentuan berikut sebelum menggunakan layanan joki dari Rookie Joki.",
    "sections": [
      {
        "icon": "badge-x",
        "title": "Bukan Afiliasi Resmi",
        "text": "Rookie Joki tidak berafiliasi secara resmi dengan Moonton atau pengembang Mobile Legends: Bang Bang. Seluruh merek dagang dan aset game adalah hak milik dari masing-masing pemiliknya."
      },
      {
        "icon": "shield",
        "title": "Tanggung Jawab Pelanggan",
        "text": "Pelanggan disarankan untuk mengamankan data pemulihan akun dan mematikan verifikasi ketat pihak ketiga sebelum menyerahkan proses pengerjaan kepada worker kami untuk kelancaran transaksi."
      }
    ],
    "policySummary": [
      {
        "label": "Afiliasi resmi Moonton",
        "value": "Tidak",
        "danger": true
      },
      {
        "label": "Keamanan data akun",
        "value": "Tanggung jawab pelanggan",
        "danger": false
      }
    ]
  },
  "footer": {
    "socialTitle": "Ikuti Sosial Media Kami",
    "socialSubtitle": "Dapatkan info promo, event, dan testimoni terbaru",
    "socialLinks": [
      {
        "platform": "Facebook",
        "url": "https://facebook.com",
        "icon": "message-square"
      },
      {
        "platform": "X (Twitter)",
        "url": "https://twitter.com",
        "icon": "x"
      },
      {
        "platform": "Instagram",
        "url": "https://instagram.com",
        "icon": "camera"
      },
      {
        "platform": "TikTok",
        "url": "https://tiktok.com",
        "icon": "music-2"
      },
      {
        "platform": "Threads",
        "url": "https://threads.net",
        "icon": "at-sign"
      }
    ],
    "line1": "Rookie Joki Official © 2021-2026. All Rights Reserved.",
    "line2": "Jasa Joki Rank Mobile Legends Terpercaya Se-Nusantara."
  },
  "blogPosts": [
    {
      "id": 1,
      "title": "Cara Ampuh Lolos Dari Epic Neraka Season Ini",
      "category": "Tips Rank",
      "excerpt": "Simak panduan memilih hero core dan manajemen waktu bermain agar cepat tembus Legend tanpa drama tim random.",
      "image": "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "01 September 2026",
      "readTime": "4 menit baca",
      "intro": "Rank Epic sering disebut 'neraka' karena kualitas tim yang naik turun drastis dibanding Grandmaster ke bawah. Di titik ini, mekanik individu saja tidak cukup — kamu butuh strategi memilih hero dan momentum match yang tepat.",
      "body1": "Masalah utama di Epic bukan skill mekanik, melainkan konsistensi. Banyak pemain punya potensi besar tapi kalah oleh tilt setelah dua atau tiga kekalahan beruntun. Kuncinya adalah menjaga rotasi permainan tetap stabil dan tidak memaksakan carry di role yang tidak dikuasai.",
      "body2": "Pilih 2-3 hero core yang benar-benar kamu kuasai luar dalam, bukan hero yang sedang tren tapi asing di tangan. Fokus pada hero dengan kurva belajar rendah namun dampak tinggi di late game, seperti fighter sustain atau marksman dengan mobilitas aman.",
      "listTitle": "Checklist sebelum push rank Epic:",
      "listItems": [
        "Mainkan di jam dengan koneksi dan mood terbaik, hindari push saat lelah.",
        "Batasi maksimal 2 kekalahan beruntun sebelum istirahat 15-30 menit.",
        "Perhatikan draft pick — jangan buta counter dari hero musuh.",
        "Prioritaskan objektif (turtle/lord) di atas kill individu."
      ],
      "closing": "Konsistensi kecil yang dijaga setiap hari jauh lebih efektif daripada maraton bermain semalaman. Kalau waktumu terbatas, jasa joki rank dari worker berpengalaman bisa jadi jalan pintas yang aman untuk melewati fase ini.",
      "tags": [
        "Epic",
        "Push Rank",
        "Solo Rank"
      ]
    },
    {
      "id": 2,
      "title": "Rekomendasi Hero Jungler Terkuat Patch Terbaru",
      "category": "Meta Update",
      "excerpt": "Daftar hero assassin dan fighter dengan winrate tertinggi yang wajib kamu pick saat solo rank musim ini.",
      "image": "https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1563089145-599997674d42?q=80&w=800&auto=format&fit=crop",
      "hasVideo": true,
      "video": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      "author": "Tim Rookie Joki",
      "date": "02 September 2026",
      "readTime": "5 menit baca",
      "intro": "Setiap patch baru selalu mengubah keseimbangan role jungler. Beberapa hero yang dulu jarang dilirik kini naik ke tier atas berkat penyesuaian item dan buff tersembunyi.",
      "body1": "Role jungler adalah salah satu posisi paling berpengaruh terhadap tempo permainan. Kemampuan clear jungle cepat, mencuri buff musuh, dan mengambil objektif di waktu yang tepat menentukan siapa yang memegang kendali map.",
      "body2": "Pada meta saat ini, hero assassin burst damage kembali populer karena rotasi item core yang lebih murah di early game, sementara fighter sustain tetap relevan untuk tim yang butuh keamanan lebih di late game.",
      "listTitle": "Kriteria memilih jungler di meta ini:",
      "listItems": [
        "Kecepatan clear jungle di 3 menit pertama.",
        "Kemampuan solo objektif (turtle/lord) tanpa bantuan tim.",
        "Fleksibilitas item untuk full damage atau hybrid tank.",
        "Mobilitas untuk gank lane sejak level 4."
      ],
      "closing": "Tren meta bisa berubah setiap update, jadi selalu cek patch note resmi sebelum menentukan hero andalan barumu.",
      "tags": [
        "Jungler",
        "Meta",
        "Tier List"
      ]
    },
    {
      "id": 3,
      "title": "5 Kesalahan Pemula yang Bikin Rank Susah Naik",
      "category": "Tips Rank",
      "excerpt": "Hindari kebiasaan buruk ini kalau kamu merasa stuck di rank yang sama selama berminggu-minggu.",
      "image": "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "03 September 2026",
      "readTime": "3 menit baca",
      "intro": "Banyak pemain baru merasa sudah bermain maksimal tapi rank tak kunjung naik. Biasanya penyebabnya bukan kurang skill, melainkan kebiasaan kecil yang berulang setiap match.",
      "body1": "Kesalahan paling umum adalah terlalu sering split push sendirian tanpa membaca posisi tim, sehingga rentan dikeroyok saat rotasi musuh datang.",
      "body2": "Selain itu, banyak pemain lupa membeli item defensif saat sudah tertinggal damage, dan tetap memaksakan build full damage meski sering dibunuh lebih dulu.",
      "listTitle": "5 kebiasaan yang wajib dihindari:",
      "listItems": [
        "Split push tanpa vision map yang cukup.",
        "Mengabaikan item defensif saat sudah sering mati duluan.",
        "Fokus war/kill dan lupa objektif utama.",
        "Emosi setelah kalah dan bermain semakin agresif tanpa strategi.",
        "Jarang membeli ward/roam skill untuk kontrol vision."
      ],
      "closing": "Perbaiki satu kebiasaan setiap minggu, dan kamu akan melihat perubahan winrate yang signifikan dalam waktu singkat.",
      "tags": [
        "Pemula",
        "Push Rank"
      ]
    },
    {
      "id": 4,
      "title": "Build Item Tersakit untuk Role Mage Assassin",
      "category": "Build & Item",
      "excerpt": "Kombinasi item burst damage yang bisa membuat mage assassin melumat carry musuh hanya dalam satu combo.",
      "image": "https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?q=80&w=800&auto=format&fit=crop",
      "hasVideo": true,
      "video": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
      "author": "Tim Rookie Joki",
      "date": "04 September 2026",
      "readTime": "4 menit baca",
      "intro": "Mage assassin dikenal karena kemampuannya menghabisi target squishy dalam sekali combo. Namun tanpa build yang tepat, potensi burst damage ini tidak akan maksimal.",
      "body1": "Kunci build mage assassin adalah memaksimalkan magic power di awal permainan sambil tetap menjaga sedikit penetrasi magic defense agar damage tetap tembus di late game.",
      "body2": "Item dengan efek pasif unik seperti stack damage bertahap atau cooldown reduction tinggi sangat cocok dipadukan dengan hero berkemampuan combo cepat.",
      "listTitle": "Urutan build yang disarankan:",
      "listItems": [
        "Item regen mana di awal untuk spam skill tanpa takut kehabisan mana.",
        "Item magic power murni sebagai core damage kedua.",
        "Item penetrasi magic defense saat musuh mulai stack item hybrid.",
        "Item survivability ringan di slot terakhir untuk war panjang."
      ],
      "closing": "Sesuaikan urutan build dengan komposisi musuh — jangan kaku pada satu pola build di setiap match.",
      "tags": [
        "Build Item",
        "Mage",
        "Burst Damage"
      ]
    },
    {
      "id": 5,
      "title": "Panduan Rotasi Peta untuk Role Roamer",
      "category": "Tutorial",
      "excerpt": "Roamer yang baik bukan yang paling banyak damage, tapi paling sering berada di tempat yang tepat.",
      "image": "https://images.unsplash.com/photo-1563089145-599997674d42?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1560253023-3ec5d502959f?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "05 September 2026",
      "readTime": "5 menit baca",
      "intro": "Peran roamer sering dianggap remeh, padahal rotasi yang tepat dari roamer bisa menentukan siapa yang memegang kendali map sejak awal permainan.",
      "body1": "Roamer bertugas menjaga keseimbangan antar lane — membantu lane yang tertinggal, memasang ward di titik vital, dan membuka war untuk tim di momen yang tepat.",
      "body2": "Manajemen waktu rotasi sangat penting: terlalu lama di satu lane membuat lane lain kehilangan bantuan, sementara rotasi terlalu cepat bisa membuat gank gagal karena buru-buru.",
      "listTitle": "Pola rotasi dasar roamer:",
      "listItems": [
        "Bantu lane exp di awal game untuk memenangkan trade level.",
        "Pasang ward di river dan jungle musuh sebelum menit ke-5.",
        "Rotasi ke mid lane saat skill hero mid sudah level 4.",
        "Selalu cek minimap tiap beberapa detik untuk peluang gank."
      ],
      "closing": "Roamer yang komunikatif dan aktif membuka peta akan sangat dihargai oleh tim, meski jarang muncul di papan MVP.",
      "tags": [
        "Roamer",
        "Rotasi",
        "Support"
      ]
    },
    {
      "id": 6,
      "title": "Jadwal Event MPL ID Season Terbaru",
      "category": "Berita Esports",
      "excerpt": "Simak jadwal lengkap pertandingan liga profesional MLBB musim ini beserta tim unggulan yang wajib ditonton.",
      "image": "https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800&auto=format&fit=crop",
      "hasVideo": true,
      "video": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "author": "Tim Rookie Joki",
      "date": "06 September 2026",
      "readTime": "3 menit baca",
      "intro": "Musim kompetitif MLBB selalu dinanti oleh komunitas, baik untuk hiburan maupun referensi meta terbaru yang dipakai tim profesional.",
      "body1": "Setiap season, format pertandingan mengalami sedikit penyesuaian mulai dari sistem regular season, playoff, hingga grand final yang biasanya digelar secara offline.",
      "body2": "Menonton pertandingan pro player juga bisa jadi cara belajar draft pick dan rotasi map tingkat tinggi yang bisa kamu tiru di rank pribadi.",
      "listTitle": "Yang perlu kamu siapkan sebelum menonton:",
      "listItems": [
        "Cek jadwal resmi di kanal streaming official liga.",
        "Perhatikan pick/ban tiap tim untuk baca tren meta terbaru.",
        "Catat rotasi item pro player untuk hero favoritmu."
      ],
      "closing": "Meta yang dipakai tim profesional biasanya turun ke rank pemain biasa dalam 1-2 minggu setelah pertandingan berlangsung.",
      "tags": [
        "MPL",
        "Esports",
        "Turnamen"
      ]
    },
    {
      "id": 7,
      "title": "Trik Membaca Draft Pick Musuh Sebelum Match",
      "category": "Strategi",
      "excerpt": "Belajar membaca komposisi musuh dari fase ban pick bisa memberimu keunggulan sebelum pertandingan dimulai.",
      "image": "https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "07 September 2026",
      "readTime": "4 menit baca",
      "intro": "Fase draft pick sering diabaikan pemain rank, padahal di sinilah pertandingan sebenarnya sudah dimulai secara tidak langsung.",
      "body1": "Perhatikan urutan ban dari musuh — hero yang di-ban lebih dulu biasanya mengindikasikan hero yang mereka takuti atau kuasai.",
      "body2": "Setelah dua atau tiga hero musuh terlihat, kamu bisa mulai memprediksi gaya bermain tim tersebut: agresif war dini atau bertahan menuju late game.",
      "listTitle": "Poin penting saat membaca draft:",
      "listItems": [
        "Identifikasi kombinasi hero combo (misalnya crowd control + burst damage).",
        "Cek apakah komposisi musuh kuat di early atau late game.",
        "Siapkan hero counter atau item penyeimbang sejak fase pick."
      ],
      "closing": "Semakin sering kamu memperhatikan pola draft, semakin cepat instingmu terbentuk untuk membaca strategi lawan.",
      "tags": [
        "Draft Pick",
        "Strategi",
        "Counter"
      ]
    },
    {
      "id": 8,
      "title": "Cara Aman Titip Akun ke Jasa Joki Terpercaya",
      "category": "Tips Keamanan",
      "excerpt": "Beberapa hal wajib kamu cek sebelum mempercayakan akun kesayanganmu ke jasa joki rank manapun.",
      "image": "https://images.unsplash.com/photo-1560253023-3ec5d502959f?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "08 September 2026",
      "readTime": "4 menit baca",
      "intro": "Keamanan akun adalah prioritas utama saat memakai jasa joki. Sayangnya tidak semua penyedia jasa memiliki standar keamanan yang sama.",
      "body1": "Pastikan kamu hanya menggunakan jasa joki yang transparan soal proses pengerjaan, memiliki testimoni jelas, dan bersedia memberikan update progres secara berkala.",
      "body2": "Selalu ganti kata sandi setelah proses joki selesai, dan aktifkan verifikasi dua langkah jika tersedia untuk mengamankan akun dari akses tidak sah di kemudian hari.",
      "listTitle": "Checklist memilih jasa joki yang aman:",
      "listItems": [
        "Ada garansi tertulis terkait keamanan akun.",
        "Worker berpengalaman dan bisa diverifikasi rekam jejaknya.",
        "Komunikasi lancar dan responsif selama proses berjalan.",
        "Metode pembayaran jelas, hindari transfer ke rekening pribadi tanpa bukti transaksi resmi."
      ],
      "closing": "Jangan tergiur harga yang terlalu murah tanpa jaminan keamanan yang jelas — akun kesayanganmu jauh lebih berharga dari selisih harga tersebut.",
      "tags": [
        "Keamanan Akun",
        "Jasa Joki"
      ]
    },
    {
      "id": 9,
      "title": "Perbandingan Role Fighter vs Assassin di Meta Ini",
      "category": "Meta Update",
      "excerpt": "Mana yang lebih worth dipakai musim ini, fighter tahan banting atau assassin burst damage instan?",
      "image": "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=800&auto=format&fit=crop",
      "hasVideo": true,
      "video": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
      "author": "Tim Rookie Joki",
      "date": "09 September 2026",
      "readTime": "4 menit baca",
      "intro": "Perdebatan fighter versus assassin selalu muncul tiap pergantian meta. Keduanya punya kelebihan yang sangat kontras satu sama lain.",
      "body1": "Fighter unggul dalam durabilitas dan konsistensi damage sepanjang pertandingan, cocok untuk pemain yang ingin selalu relevan di setiap fase permainan.",
      "body2": "Sementara itu, assassin unggul dalam menentukan momentum war lewat satu kill instan pada carry musuh, namun rentan mati jika timing eksekusinya meleset.",
      "listTitle": "Pertimbangan memilih role:",
      "listItems": [
        "Pilih fighter jika kamu ingin peran yang lebih forgiving untuk kesalahan kecil.",
        "Pilih assassin jika kamu percaya diri dengan timing dan mekanik combo.",
        "Sesuaikan dengan sisa komposisi tim agar tidak kekurangan damage atau tank."
      ],
      "closing": "Tidak ada yang mutlak lebih baik — keduanya efektif jika dimainkan sesuai kondisi tim dan gaya bermainmu.",
      "tags": [
        "Fighter",
        "Assassin",
        "Meta"
      ]
    },
    {
      "id": 10,
      "title": "7 Hero Termudah untuk Push Rank Solo",
      "category": "Hero Guide",
      "excerpt": "Cocok untuk kamu yang sering main solo tanpa squad tetap dan butuh hero yang forgiving.",
      "image": "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "10 September 2026",
      "readTime": "4 menit baca",
      "intro": "Bermain solo rank menuntut hero yang tidak terlalu bergantung pada koordinasi tim, namun tetap punya dampak besar di setiap fase permainan.",
      "body1": "Hero dengan kurva belajar rendah namun scaling damage yang stabil adalah pilihan ideal, karena kamu tidak bisa selalu mengandalkan rotasi tim yang solid saat main sendirian.",
      "body2": "Selain kemudahan mekanik, pertimbangkan juga hero dengan kemampuan self-sustain agar tetap bisa bertahan meski war berjalan tidak sesuai rencana.",
      "listTitle": "Kriteria hero ramah untuk solo rank:",
      "listItems": [
        "Skill set sederhana namun scaling damage tetap relevan di late game.",
        "Punya kemampuan self-peel atau mobilitas untuk kabur dari gank.",
        "Tidak terlalu bergantung pada kombo dengan hero lain."
      ],
      "closing": "Kuasai 2-3 hero dari kategori ini secara mendalam sebelum mencoba memperluas hero pool-mu.",
      "tags": [
        "Hero Guide",
        "Solo Rank",
        "Pemula"
      ]
    },
    {
      "id": 11,
      "title": "Update Patch Note Terbaru: Nerf & Buff Hero",
      "category": "Berita",
      "excerpt": "Rangkuman perubahan balance terbaru yang wajib kamu ketahui sebelum masuk rank hari ini.",
      "image": "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "11 September 2026",
      "readTime": "3 menit baca",
      "intro": "Setiap update balance membawa dampak signifikan terhadap tier list dan strategi yang berlaku di rank maupun turnamen profesional.",
      "body1": "Beberapa hero yang sebelumnya dominan mengalami penyesuaian cooldown dan base damage, sementara hero yang jarang dipakai mendapat sedikit peningkatan agar lebih kompetitif.",
      "body2": "Selain hero, beberapa item core juga mengalami perubahan harga dan efek pasif yang berdampak langsung pada urutan build optimal di setiap role.",
      "listTitle": "Hal yang perlu dipantau setelah update:",
      "listItems": [
        "Perubahan cooldown skill utama hero favoritmu.",
        "Penyesuaian harga dan efek item inti di build biasanya kamu pakai.",
        "Hero baru yang mungkin masuk ke tier list atas."
      ],
      "closing": "Selalu baca patch note resmi secara lengkap agar strategi bermainmu tidak ketinggalan zaman.",
      "tags": [
        "Patch Note",
        "Balance",
        "Update"
      ]
    },
    {
      "id": 12,
      "title": "Rahasia Farming Cepat di 5 Menit Awal",
      "category": "Tips Rank",
      "excerpt": "Efisiensi farming di early game jadi penentu siapa yang lebih dulu unggul item core saat war pertama pecah.",
      "image": "https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1563089145-599997674d42?q=80&w=800&auto=format&fit=crop",
      "hasVideo": true,
      "video": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      "author": "Tim Rookie Joki",
      "date": "12 September 2026",
      "readTime": "3 menit baca",
      "intro": "Farming efisien di lima menit pertama sering menjadi pembeda antara pemain rank atas dan pemain casual, meski mekanik individunya setara.",
      "body1": "Pola farming yang baik memastikan tidak ada minion atau jungle monster yang terlewat, sambil tetap menjaga posisi aman dari ancaman gank musuh.",
      "body2": "Gunakan skill non-ultimate untuk membersihkan wave dengan cepat, dan simpan mana untuk skill utama saat trade lane atau war kecil terjadi.",
      "listTitle": "Rute farming efisien:",
      "listItems": [
        "Bersihkan wave lane dulu sebelum masuk ke jungle terdekat.",
        "Prioritaskan buff merah/biru sesuai kebutuhan role.",
        "Selalu cek minimap sebelum masuk area jungle musuh."
      ],
      "closing": "Farming yang rapi di awal game akan memberi keunggulan gold yang signifikan menjelang war pertama.",
      "tags": [
        "Farming",
        "Early Game"
      ]
    },
    {
      "id": 13,
      "title": "Kombinasi Emblem Terbaik untuk Setiap Role",
      "category": "Build & Item",
      "excerpt": "Emblem yang tepat bisa memaksimalkan potensi hero, mulai dari role tank hingga marksman.",
      "image": "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "13 September 2026",
      "readTime": "4 menit baca",
      "intro": "Emblem sering dianggap sepele, padahal pengaturan talent yang tepat bisa memberi peningkatan performa yang cukup terasa di setiap role.",
      "body1": "Setiap role punya kebutuhan atribut yang berbeda — tank membutuhkan sustain dan reduksi damage, sementara marksman lebih diuntungkan oleh talent yang meningkatkan basic attack.",
      "body2": "Jangan lupa sesuaikan talent tambahan sesuai kondisi pertandingan, misalnya memilih talent movement speed saat menghadapi tim dengan mobilitas tinggi.",
      "listTitle": "Rekomendasi dasar emblem per role:",
      "listItems": [
        "Tank: talent sustain dan pengurangan damage masuk.",
        "Marksman: talent peningkatan basic attack dan movement speed.",
        "Mage: talent pengurangan cooldown dan penetrasi magic defense.",
        "Assassin: talent burst damage tambahan di awal combo."
      ],
      "closing": "Eksperimen kecil pada pilihan talent bisa memberi dampak besar terhadap gaya bermain hero favoritmu.",
      "tags": [
        "Emblem",
        "Build Item"
      ]
    },
    {
      "id": 14,
      "title": "Cara Komunikasi Efektif dengan Tim di Rank",
      "category": "Tips Mabar",
      "excerpt": "Komunikasi yang tepat bisa mengubah tim random menjadi solid tanpa perlu voice chat panjang lebar.",
      "image": "https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "14 September 2026",
      "readTime": "3 menit baca",
      "intro": "Komunikasi bukan soal banyak bicara, tapi soal menyampaikan informasi penting secara singkat dan tepat waktu kepada tim.",
      "body1": "Gunakan quick chat atau ping secara efektif untuk memberi tahu posisi musuh, permintaan bantuan, atau rencana rotasi tanpa perlu mengetik panjang.",
      "body2": "Hindari komunikasi yang bernada menyalahkan saat tim kalah trade, karena hal ini justru menurunkan mood dan performa tim di sisa pertandingan.",
      "listTitle": "Tips komunikasi singkat namun efektif:",
      "listItems": [
        "Gunakan ping/danger secara konsisten saat musuh terlihat hilang dari map.",
        "Sampaikan rencana war lewat quick chat sebelum inisiasi.",
        "Berikan apresiasi singkat pada rekan tim setelah play bagus."
      ],
      "closing": "Tim dengan komunikasi positif cenderung lebih tenang mengambil keputusan, bahkan saat tertinggal skor.",
      "tags": [
        "Komunikasi",
        "Mabar",
        "Tim"
      ]
    },
    {
      "id": 15,
      "title": "Mengenal Sistem Matchmaking dan Hidden MMR",
      "category": "Edukasi",
      "excerpt": "Kenapa kadang lawan terasa jauh lebih kuat meski rank terlihat sama? Ini penjelasannya.",
      "image": "https://images.unsplash.com/photo-1563089145-599997674d42?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1560253023-3ec5d502959f?q=80&w=800&auto=format&fit=crop",
      "hasVideo": true,
      "video": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
      "author": "Tim Rookie Joki",
      "date": "15 September 2026",
      "readTime": "5 menit baca",
      "intro": "Sistem matchmaking modern tidak hanya melihat rank yang terlihat di profil, tapi juga nilai tersembunyi bernama hidden MMR (Match Making Rating).",
      "body1": "Hidden MMR memperhitungkan performa individu dalam beberapa match terakhir, bukan hanya menang atau kalah semata, sehingga dua pemain di rank yang sama bisa punya tingkat kesulitan lawan yang berbeda.",
      "body2": "Inilah kenapa terkadang kamu merasa lawan jauh lebih 'jago' dari rank yang ditampilkan — sistem sedang menyesuaikan tantangan berdasarkan performa terbaru.",
      "listTitle": "Fakta seputar hidden MMR:",
      "listItems": [
        "Winrate tinggi secara konsisten bisa membuat MMR naik lebih cepat dari rank yang terlihat.",
        "Performa individu tetap dihitung meski tim kalah.",
        "MMR bisa menyesuaikan ulang setelah periode tidak aktif bermain."
      ],
      "closing": "Memahami konsep ini membantu kamu lebih tenang menghadapi lawan yang terasa berat, karena itu tandanya performamu sedang meningkat.",
      "tags": [
        "Matchmaking",
        "MMR",
        "Edukasi"
      ]
    },
    {
      "id": 16,
      "title": "Review Skin Collector Terbaru: Worth It?",
      "category": "Review",
      "excerpt": "Ulasan jujur soal efek visual, sound effect, hingga worth atau tidaknya membeli skin collector musim ini.",
      "image": "https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "16 September 2026",
      "readTime": "4 menit baca",
      "intro": "Skin collector selalu menarik perhatian karena efek visual dan sound effect eksklusif yang ditawarkan, namun harganya juga tidak murah.",
      "body1": "Dari sisi visual, skin collector biasanya membawa efek partikel dan animasi recall yang jauh lebih detail dibanding skin epic biasa.",
      "body2": "Namun perlu dicatat, efek gameplay seperti hitbox dan animasi skill tetap sama — jadi keputusan membeli sebaiknya murni berdasarkan preferensi estetika, bukan ekspektasi buff tersembunyi.",
      "listTitle": "Poin evaluasi sebelum membeli:",
      "listItems": [
        "Perhatikan preview animasi skill di server uji coba jika tersedia.",
        "Cek apakah hero tersebut memang sering kamu mainkan.",
        "Bandingkan harga dengan event diskon yang mungkin akan datang."
      ],
      "closing": "Skin adalah preferensi personal — beli karena suka, bukan karena tekanan tren semata.",
      "tags": [
        "Skin",
        "Review",
        "Collector"
      ]
    },
    {
      "id": 17,
      "title": "Panduan Lengkap Jadi Support Andal",
      "category": "Hero Guide",
      "excerpt": "Support yang baik adalah yang membuat carry-nya nyaman farming tanpa gangguan berarti.",
      "image": "https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "17 September 2026",
      "readTime": "4 menit baca",
      "intro": "Role support sering dinilai dari jumlah assist, padahal peran sesungguhnya jauh lebih kompleks dari sekadar mendampingi carry.",
      "body1": "Support yang baik memahami kapan harus agresif membuka war dan kapan harus bertahan menjaga posisi carry tetap aman dari incaran musuh.",
      "body2": "Selain itu, pengaturan vision lewat ward dan roam skill sangat menentukan seberapa besar kontrol tim terhadap map secara keseluruhan.",
      "listTitle": "Fokus utama seorang support:",
      "listItems": [
        "Jaga posisi carry tetap aman selama war berlangsung.",
        "Pasang ward di titik-titik vital secara konsisten.",
        "Buka war di momen yang menguntungkan tim, bukan asal inisiasi."
      ],
      "closing": "Support yang solid sering menjadi pembeda antara tim yang menang war dan yang kalah, meski jarang tampil di top score.",
      "tags": [
        "Support",
        "Hero Guide"
      ]
    },
    {
      "id": 18,
      "title": "Kisah Sukses Worker Rookie Joki Tembus Mythic",
      "category": "Cerita",
      "excerpt": "Cerita inspiratif salah satu worker kami yang konsisten menyelesaikan ratusan pesanan joki tanpa satupun laporan minus.",
      "image": "https://images.unsplash.com/photo-1560253023-3ec5d502959f?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop",
      "hasVideo": true,
      "video": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
      "author": "Tim Rookie Joki",
      "date": "18 September 2026",
      "readTime": "3 menit baca",
      "intro": "Di balik setiap pesanan joki yang selesai dengan winrate tinggi, ada worker yang berdedikasi menjaga kualitas dan kepercayaan pelanggan.",
      "body1": "Salah satu worker senior kami memulai karier dari rank Epic dan kini menjadi salah satu penyumbang winrate tertinggi di leaderboard internal Rookie Joki.",
      "body2": "Menurutnya, kunci sukses bukan hanya soal mekanik individu, tapi juga kedisiplinan menjaga fokus dan komunikasi jujur dengan tim maupun pelanggan.",
      "listTitle": "Pelajaran dari kisah ini:",
      "listItems": [
        "Konsistensi jangka panjang mengalahkan skill instan semata.",
        "Kepercayaan pelanggan dibangun dari transparansi proses.",
        "Selalu ada ruang untuk berkembang, di rank manapun kamu berada."
      ],
      "closing": "Kisah ini menjadi pengingat bahwa dedikasi dan kejujuran tetap jadi fondasi utama layanan jasa joki yang berkualitas.",
      "tags": [
        "Cerita",
        "Worker",
        "Inspirasi"
      ]
    },
    {
      "id": 19,
      "title": "Tips Mental Bermain Saat Lose Streak",
      "category": "Tips Mabar",
      "excerpt": "Lose streak adalah bagian dari perjalanan rank siapapun. Ini cara menjaga mental tetap stabil menghadapinya.",
      "image": "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=800&auto=format&fit=crop",
      "hasVideo": false,
      "video": "",
      "author": "Tim Rookie Joki",
      "date": "19 September 2026",
      "readTime": "3 menit baca",
      "intro": "Lose streak bisa terjadi pada siapa saja, bahkan pemain dengan mekanik terbaik sekalipun. Cara meresponsnya yang menentukan seberapa cepat kamu bangkit.",
      "body1": "Saat kalah beruntun, tubuh dan pikiran cenderung lebih tegang, membuat pengambilan keputusan di dalam game menjadi kurang optimal dibanding kondisi normal.",
      "body2": "Mengenali tanda-tanda tilt sejak dini — seperti emosi saat draft pick atau ingin buru-buru war tanpa strategi — bisa membantumu mengambil jeda sebelum kondisi memburuk.",
      "listTitle": "Cara menjaga mental saat lose streak:",
      "listItems": [
        "Istirahat singkat setelah dua kekalahan beruntun.",
        "Hindari membaca chat toxic secara berlebihan.",
        "Fokus pada perbaikan personal, bukan mencari kambing hitam."
      ],
      "closing": "Rank naik turun adalah hal wajar — yang membedakan pemain hebat adalah kemampuan mereka bangkit lebih cepat dari lose streak.",
      "tags": [
        "Mental",
        "Lose Streak",
        "Tips Mabar"
      ]
    },
    {
      "id": 20,
      "title": "Bocoran Hero Baru & Revamp Mendatang",
      "category": "Berita",
      "excerpt": "Info awal seputar hero baru dan rencana revamp hero lama yang akan hadir di update mendatang.",
      "image": "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?q=80&w=800&auto=format&fit=crop",
      "secondaryImage": "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?q=80&w=800&auto=format&fit=crop",
      "hasVideo": true,
      "video": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
      "author": "Tim Rookie Joki",
      "date": "20 September 2026",
      "readTime": "3 menit baca",
      "intro": "Setiap beberapa update, developer game biasanya menghadirkan hero baru sekaligus melakukan revamp pada hero lama yang dianggap kurang relevan di meta saat ini.",
      "body1": "Revamp biasanya menyasar hero dengan winrate dan pick rate rendah dalam waktu lama, memberikan mereka mekanik skill baru yang lebih sesuai dengan kondisi meta terkini.",
      "body2": "Sementara hero baru umumnya membawa mekanik unik yang belum pernah ada sebelumnya, sehingga wajar jika membutuhkan waktu adaptasi sebelum benar-benar dikuasai banyak pemain.",
      "listTitle": "Yang perlu disiapkan menyambut update ini:",
      "listItems": [
        "Ikuti kanal resmi untuk info rilis dan jadwal revamp.",
        "Coba hero baru di mode latihan sebelum dibawa ke rank.",
        "Pantau perubahan tier list dalam minggu pertama rilis."
      ],
      "closing": "Perubahan seperti ini selalu jadi momen seru untuk menemukan gaya bermain baru di MLBB.",
      "tags": [
        "Hero Baru",
        "Revamp",
        "Berita"
      ]
    }
  ],
  "blogNextId": 21,
  "categoryColors": {
    "Tips Rank": [
      "bg-blue-100",
      "text-blue-700"
    ],
    "Meta Update": [
      "bg-emerald-100",
      "text-emerald-700"
    ],
    "Tutorial": [
      "bg-indigo-100",
      "text-indigo-700"
    ],
    "Berita Esports": [
      "bg-rose-100",
      "text-rose-700"
    ],
    "Strategi": [
      "bg-purple-100",
      "text-purple-700"
    ],
    "Tips Keamanan": [
      "bg-amber-100",
      "text-amber-700"
    ],
    "Hero Guide": [
      "bg-cyan-100",
      "text-cyan-700"
    ],
    "Berita": [
      "bg-rose-100",
      "text-rose-700"
    ],
    "Build & Item": [
      "bg-orange-100",
      "text-orange-700"
    ],
    "Tips Mabar": [
      "bg-teal-100",
      "text-teal-700"
    ],
    "Edukasi": [
      "bg-slate-200",
      "text-slate-700"
    ],
    "Review": [
      "bg-pink-100",
      "text-pink-700"
    ],
    "Cerita": [
      "bg-lime-100",
      "text-lime-700"
    ]
  },
  "testimonials": [
    {
      "id": 73,
      "name": "Ayu F.",
      "service": "Joki Solo Rank Aman",
      "comment": "Winrate naik drastis, hero yang dipakai juga sesuai request aku.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "14 Sep 2026",
      "daysAgo": 1
    },
    {
      "id": 4,
      "name": "Ulfa N.",
      "service": "Joki Grandmaster ke Epic",
      "comment": "Udah langganan dari season lalu, selalu puas sama kerjaan tim Rookie Joki.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "13 Sep 2026",
      "daysAgo": 2
    },
    {
      "id": 30,
      "name": "Eka A.",
      "service": "Joki Rank Epic ke Legend",
      "comment": "Harga bersahabat buat mahasiswa kayak aku, kualitas tetap oke.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "13 Sep 2026",
      "daysAgo": 2
    },
    {
      "id": 19,
      "name": "Ayu D.",
      "service": "Joki Legend ke Mythic",
      "comment": "Garansi winrate beneran ditepati, gak php sama sekali.",
      "badge": "Pembeli Asli",
      "rating": 3,
      "date": "12 Sep 2026",
      "daysAgo": 3
    },
    {
      "id": 100,
      "name": "Xena L.",
      "service": "Push Mythic Glory",
      "comment": "Winrate naik drastis, hero yang dipakai juga sesuai request aku.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "8 Sep 2026",
      "daysAgo": 7
    },
    {
      "id": 31,
      "name": "Eka L.",
      "service": "Paket Kilat 5 Bintang",
      "comment": "Worker-nya ramah dan komunikatif, update progress terus tiap match selesai.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "6 Sep 2026",
      "daysAgo": 9
    },
    {
      "id": 58,
      "name": "Lutfi R.",
      "service": "Joki Grandmaster ke Epic",
      "comment": "Awalnya ragu tapi ternyata beneran aman dan hasilnya sesuai janji.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "4 Sep 2026",
      "daysAgo": 11
    },
    {
      "id": 17,
      "name": "Zaki M.",
      "service": "Joki Placement 10 Match",
      "comment": "Garansi winrate beneran ditepati, gak php sama sekali.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "2 Sep 2026",
      "daysAgo": 13
    },
    {
      "id": 54,
      "name": "Nanda F.",
      "service": "Paket Kilat 5 Bintang",
      "comment": "Progress bisa dipantau terus, jadi tenang nungguin akun selesai dikerjain.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "1 Sep 2026",
      "daysAgo": 14
    },
    {
      "id": 12,
      "name": "Kevin H.",
      "service": "Joki Grandmaster ke Epic",
      "comment": "Progress bisa dipantau terus, jadi tenang nungguin akun selesai dikerjain.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "31 Aug 2026",
      "daysAgo": 15
    },
    {
      "id": 42,
      "name": "Nanda P.",
      "service": "Joki Turnamen MRO",
      "comment": "Pelayanan ramah dari awal chat sampai laporan selesai pengerjaan.",
      "badge": "Terverifikasi",
      "rating": 4,
      "date": "31 Aug 2026",
      "daysAgo": 15
    },
    {
      "id": 39,
      "name": "Kevin W.",
      "service": "Joki Legend ke Mythic",
      "comment": "Recommended buat yang sibuk tapi masih pengen naik rank tiap season.",
      "badge": "Terverifikasi",
      "rating": 4,
      "date": "30 Aug 2026",
      "daysAgo": 16
    },
    {
      "id": 8,
      "name": "Fajar N.",
      "service": "Push 25 Bintang Mythic",
      "comment": "Bakal jadi langganan tetap tiap mau push rank akhir season.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "28 Aug 2026",
      "daysAgo": 18
    },
    {
      "id": 64,
      "name": "Oscar P.",
      "service": "Paket Kilat 5 Bintang",
      "comment": "Fast respon admin pas nanya-nanya sebelum order, mantap pelayanannya.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "28 Aug 2026",
      "daysAgo": 18
    },
    {
      "id": 85,
      "name": "Qori K.",
      "service": "Boost Winrate Hero Core",
      "comment": "Recommended buat yang sibuk tapi masih pengen naik rank tiap season.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "26 Aug 2026",
      "daysAgo": 20
    },
    {
      "id": 95,
      "name": "Wahyu T.",
      "service": "Joki Grandmaster ke Epic",
      "comment": "Progress bisa dipantau terus, jadi tenang nungguin akun selesai dikerjain.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "25 Aug 2026",
      "daysAgo": 21
    },
    {
      "id": 2,
      "name": "Tegar L.",
      "service": "Boost Winrate Hero Core",
      "comment": "Akun aman, gak ada masalah setelah selesai dikerjain. Puas sama hasilnya.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "22 Aug 2026",
      "daysAgo": 24
    },
    {
      "id": 9,
      "name": "Citra F.",
      "service": "Joki Winrate Fanny 85%",
      "comment": "Selesai lebih cepat dari estimasi, worker jago banget mainnya.",
      "badge": "Terverifikasi",
      "rating": 4,
      "date": "20 Aug 2026",
      "daysAgo": 26
    },
    {
      "id": 1,
      "name": "Qori S.",
      "service": "Joki Rank Epic ke Legend",
      "comment": "Progress bisa dipantau terus, jadi tenang nungguin akun selesai dikerjain.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "19 Aug 2026",
      "daysAgo": 27
    },
    {
      "id": 52,
      "name": "Umar G.",
      "service": "Paket Kilat 5 Bintang",
      "comment": "Harga worth it banget dibanding jasa joki lain, plus ada garansi juga.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "18 Aug 2026",
      "daysAgo": 28
    },
    {
      "id": 24,
      "name": "Krisna T.",
      "service": "Boost Winrate Hero Core",
      "comment": "Prosesnya cepat banget, gak nyangka semalam langsung naik rank. Recommended!",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "17 Aug 2026",
      "daysAgo": 29
    },
    {
      "id": 56,
      "name": "Qori K.",
      "service": "Joki Placement 10 Match",
      "comment": "Squad-nya solid, mabar bareng jadi lebih seru dan hasilnya maksimal.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "17 Aug 2026",
      "daysAgo": 29
    },
    {
      "id": 98,
      "name": "Budi D.",
      "service": "Joki Placement 10 Match",
      "comment": "Udah langganan dari season lalu, selalu puas sama kerjaan tim Rookie Joki.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "16 Aug 2026",
      "daysAgo": 30
    },
    {
      "id": 81,
      "name": "Jihan H.",
      "service": "Joki Rank Epic ke Legend",
      "comment": "Pelayanan ramah dari awal chat sampai laporan selesai pengerjaan.",
      "badge": "Terverifikasi",
      "rating": 4,
      "date": "14 Aug 2026",
      "daysAgo": 32
    },
    {
      "id": 49,
      "name": "Maya S.",
      "service": "Push Mythic Glory",
      "comment": "Pelayanan ramah dari awal chat sampai laporan selesai pengerjaan.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "12 Aug 2026",
      "daysAgo": 34
    },
    {
      "id": 55,
      "name": "Fajar F.",
      "service": "Joki Grandmaster ke Epic",
      "comment": "Progress bisa dipantau terus, jadi tenang nungguin akun selesai dikerjain.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "12 Aug 2026",
      "daysAgo": 34
    },
    {
      "id": 79,
      "name": "Mega L.",
      "service": "Joki Solo Rank Aman",
      "comment": "Sempet ada kendala kecil tapi langsung ditangani admin dengan cepat.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "8 Aug 2026",
      "daysAgo": 38
    },
    {
      "id": 23,
      "name": "Qori N.",
      "service": "Joki Turnamen MRO",
      "comment": "Fast respon admin pas nanya-nanya sebelum order, mantap pelayanannya.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "4 Aug 2026",
      "daysAgo": 42
    },
    {
      "id": 60,
      "name": "Chandra D.",
      "service": "Joki Solo Rank Aman",
      "comment": "Awalnya ragu tapi ternyata beneran aman dan hasilnya sesuai janji.",
      "badge": "Terverifikasi",
      "rating": 4,
      "date": "31 Jul 2026",
      "daysAgo": 46
    },
    {
      "id": 36,
      "name": "Gilang M.",
      "service": "Joki Winrate Fanny 85%",
      "comment": "Fast respon admin pas nanya-nanya sebelum order, mantap pelayanannya.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "30 Jul 2026",
      "daysAgo": 47
    },
    {
      "id": 68,
      "name": "Dian D.",
      "service": "Boost Winrate Hero Core",
      "comment": "Harga worth it banget dibanding jasa joki lain, plus ada garansi juga.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "28 Jul 2026",
      "daysAgo": 49
    },
    {
      "id": 97,
      "name": "Oscar F.",
      "service": "Push Mythic Glory",
      "comment": "Worker-nya ramah dan komunikatif, update progress terus tiap match selesai.",
      "badge": "Terverifikasi",
      "rating": 3,
      "date": "25 Jul 2026",
      "daysAgo": 52
    },
    {
      "id": 46,
      "name": "Salsa D.",
      "service": "Joki Turnamen MRO",
      "comment": "Garansi winrate beneran ditepati, gak php sama sekali.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "24 Jul 2026",
      "daysAgo": 53
    },
    {
      "id": 88,
      "name": "Eka W.",
      "service": "Joki Grandmaster ke Epic",
      "comment": "Pertama kali coba jasa joki dan langsung cocok, bakal order lagi nanti.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "24 Jul 2026",
      "daysAgo": 53
    },
    {
      "id": 10,
      "name": "Ayu K.",
      "service": "Joki Legend ke Mythic",
      "comment": "Privasi akun terjaga, gak ada history aneh-aneh pas cek ulang.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "23 Jul 2026",
      "daysAgo": 54
    },
    {
      "id": 13,
      "name": "Oscar B.",
      "service": "Joki Rank Epic ke Legend",
      "comment": "Pertama kali coba jasa joki dan langsung cocok, bakal order lagi nanti.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "22 Jul 2026",
      "daysAgo": 55
    },
    {
      "id": 32,
      "name": "Wahyu S.",
      "service": "Boost Winrate Hero Core",
      "comment": "Udah langganan dari season lalu, selalu puas sama kerjaan tim Rookie Joki.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "22 Jul 2026",
      "daysAgo": 55
    },
    {
      "id": 87,
      "name": "Fajar R.",
      "service": "Joki Placement 10 Match",
      "comment": "Udah langganan dari season lalu, selalu puas sama kerjaan tim Rookie Joki.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "22 Jul 2026",
      "daysAgo": 55
    },
    {
      "id": 5,
      "name": "Yoga T.",
      "service": "Joki Placement 10 Match",
      "comment": "Push rank sambil kerja jadi gak kepikiran lagi, tinggal terima beres.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "21 Jul 2026",
      "daysAgo": 56
    },
    {
      "id": 29,
      "name": "Reza A.",
      "service": "Joki Legend ke Mythic",
      "comment": "Garansi winrate beneran ditepati, gak php sama sekali.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "19 Jul 2026",
      "daysAgo": 58
    },
    {
      "id": 63,
      "name": "Oscar M.",
      "service": "Joki Legend ke Mythic",
      "comment": "Privasi akun terjaga, gak ada history aneh-aneh pas cek ulang.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "18 Jul 2026",
      "daysAgo": 59
    },
    {
      "id": 38,
      "name": "Gilang P.",
      "service": "Paket Kilat 5 Bintang",
      "comment": "Pelayanan ramah dari awal chat sampai laporan selesai pengerjaan.",
      "badge": "Terverifikasi",
      "rating": 3,
      "date": "16 Jul 2026",
      "daysAgo": 61
    },
    {
      "id": 44,
      "name": "Fajar B.",
      "service": "Joki Placement 10 Match",
      "comment": "Akun aman, gak ada masalah setelah selesai dikerjain. Puas sama hasilnya.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "16 Jul 2026",
      "daysAgo": 61
    },
    {
      "id": 76,
      "name": "Ivan F.",
      "service": "Paket Kilat 5 Bintang",
      "comment": "Bakal jadi langganan tetap tiap mau push rank akhir season.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "16 Jul 2026",
      "daysAgo": 61
    },
    {
      "id": 11,
      "name": "Salsa K.",
      "service": "Joki Solo Rank Aman",
      "comment": "Akun aman, gak ada masalah setelah selesai dikerjain. Puas sama hasilnya.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "14 Jul 2026",
      "daysAgo": 63
    },
    {
      "id": 77,
      "name": "Tegar K.",
      "service": "Joki Winrate Fanny 85%",
      "comment": "Fast respon admin pas nanya-nanya sebelum order, mantap pelayanannya.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "14 Jul 2026",
      "daysAgo": 63
    },
    {
      "id": 61,
      "name": "Chandra P.",
      "service": "Joki Placement 10 Match",
      "comment": "Pertama kali coba jasa joki dan langsung cocok, bakal order lagi nanti.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "13 Jul 2026",
      "daysAgo": 64
    },
    {
      "id": 84,
      "name": "Erlangga G.",
      "service": "Joki Placement 10 Match",
      "comment": "Recommended buat yang sibuk tapi masih pengen naik rank tiap season.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "13 Jul 2026",
      "daysAgo": 64
    },
    {
      "id": 21,
      "name": "Hana K.",
      "service": "Joki Grandmaster ke Epic",
      "comment": "Winrate naik drastis, hero yang dipakai juga sesuai request aku.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "9 Jul 2026",
      "daysAgo": 68
    },
    {
      "id": 66,
      "name": "Wahyu P.",
      "service": "Push Mythic Glory",
      "comment": "Progress bisa dipantau terus, jadi tenang nungguin akun selesai dikerjain.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "9 Jul 2026",
      "daysAgo": 68
    },
    {
      "id": 90,
      "name": "Umar T.",
      "service": "Joki Grandmaster ke Epic",
      "comment": "Push rank sambil kerja jadi gak kepikiran lagi, tinggal terima beres.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "7 Jul 2026",
      "daysAgo": 70
    },
    {
      "id": 75,
      "name": "Tegar M.",
      "service": "Boost Winrate Hero Core",
      "comment": "Recommended buat yang sibuk tapi masih pengen naik rank tiap season.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "4 Jul 2026",
      "daysAgo": 73
    },
    {
      "id": 41,
      "name": "Taufik W.",
      "service": "Joki Solo Rank Aman",
      "comment": "Pelayanan ramah dari awal chat sampai laporan selesai pengerjaan.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "1 Jul 2026",
      "daysAgo": 76
    },
    {
      "id": 22,
      "name": "Ivan T.",
      "service": "Joki Placement 10 Match",
      "comment": "Garansi winrate beneran ditepati, gak php sama sekali.",
      "badge": "Terverifikasi",
      "rating": 4,
      "date": "30 Jun 2026",
      "daysAgo": 77
    },
    {
      "id": 67,
      "name": "Citra S.",
      "service": "Joki Turnamen MRO",
      "comment": "Push rank sambil kerja jadi gak kepikiran lagi, tinggal terima beres.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "26 Jun 2026",
      "daysAgo": 81
    },
    {
      "id": 94,
      "name": "Lina P.",
      "service": "Push 25 Bintang Mythic",
      "comment": "Sempet ada kendala kecil tapi langsung ditangani admin dengan cepat.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "23 Jun 2026",
      "daysAgo": 84
    },
    {
      "id": 35,
      "name": "Fitri B.",
      "service": "Joki Solo Rank Aman",
      "comment": "Worker-nya ramah dan komunikatif, update progress terus tiap match selesai.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "20 Jun 2026",
      "daysAgo": 87
    },
    {
      "id": 20,
      "name": "Tegar L.",
      "service": "Push Mythic Glory",
      "comment": "Pelayanan ramah dari awal chat sampai laporan selesai pengerjaan.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "19 Jun 2026",
      "daysAgo": 88
    },
    {
      "id": 53,
      "name": "Xena N.",
      "service": "Joki Placement 10 Match",
      "comment": "Progress bisa dipantau terus, jadi tenang nungguin akun selesai dikerjain.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "19 Jun 2026",
      "daysAgo": 88
    },
    {
      "id": 6,
      "name": "Yoga A.",
      "service": "Push Mythic Glory",
      "comment": "Akun aman, gak ada masalah setelah selesai dikerjain. Puas sama hasilnya.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "18 Jun 2026",
      "daysAgo": 89
    },
    {
      "id": 96,
      "name": "Galih P.",
      "service": "Joki Solo Rank Aman",
      "comment": "Pelayanan ramah dari awal chat sampai laporan selesai pengerjaan.",
      "badge": "Terverifikasi",
      "rating": 3,
      "date": "17 Jun 2026",
      "daysAgo": 90
    },
    {
      "id": 89,
      "name": "Chandra W.",
      "service": "Joki Turnamen MRO",
      "comment": "Prosesnya cepat banget, gak nyangka semalam langsung naik rank. Recommended!",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "16 Jun 2026",
      "daysAgo": 91
    },
    {
      "id": 7,
      "name": "Okta K.",
      "service": "Joki Rank Epic ke Legend",
      "comment": "Squad-nya solid, mabar bareng jadi lebih seru dan hasilnya maksimal.",
      "badge": "Terverifikasi",
      "rating": 3,
      "date": "10 Jun 2026",
      "daysAgo": 97
    },
    {
      "id": 18,
      "name": "Hana R.",
      "service": "Paket Kilat 5 Bintang",
      "comment": "Winrate naik drastis, hero yang dipakai juga sesuai request aku.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "8 Jun 2026",
      "daysAgo": 99
    },
    {
      "id": 14,
      "name": "Maya G.",
      "service": "Joki Solo Rank Aman",
      "comment": "Pertama kali coba jasa joki dan langsung cocok, bakal order lagi nanti.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "5 Jun 2026",
      "daysAgo": 102
    },
    {
      "id": 16,
      "name": "Krisna K.",
      "service": "Joki Solo Rank Aman",
      "comment": "Harga bersahabat buat mahasiswa kayak aku, kualitas tetap oke.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "4 Jun 2026",
      "daysAgo": 103
    },
    {
      "id": 91,
      "name": "Dian H.",
      "service": "Joki Rank Epic ke Legend",
      "comment": "Sempet ada kendala kecil tapi langsung ditangani admin dengan cepat.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "3 Jun 2026",
      "daysAgo": 104
    },
    {
      "id": 34,
      "name": "Chandra M.",
      "service": "Push Mythic Glory",
      "comment": "Harga worth it banget dibanding jasa joki lain, plus ada garansi juga.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "1 Jun 2026",
      "daysAgo": 106
    },
    {
      "id": 45,
      "name": "Bagas S.",
      "service": "Joki Turnamen MRO",
      "comment": "Udah langganan dari season lalu, selalu puas sama kerjaan tim Rookie Joki.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "30 May 2026",
      "daysAgo": 108
    },
    {
      "id": 50,
      "name": "Yusuf G.",
      "service": "Push Mythic Glory",
      "comment": "Udah langganan dari season lalu, selalu puas sama kerjaan tim Rookie Joki.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "25 May 2026",
      "daysAgo": 113
    },
    {
      "id": 74,
      "name": "Umar K.",
      "service": "Joki Winrate Fanny 85%",
      "comment": "Push rank sambil kerja jadi gak kepikiran lagi, tinggal terima beres.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "24 May 2026",
      "daysAgo": 114
    },
    {
      "id": 82,
      "name": "Fitri R.",
      "service": "Joki Legend ke Mythic",
      "comment": "Garansi winrate beneran ditepati, gak php sama sekali.",
      "badge": "Pembeli Asli",
      "rating": 3,
      "date": "24 May 2026",
      "daysAgo": 114
    },
    {
      "id": 40,
      "name": "Kevin W.",
      "service": "Joki Rank Epic ke Legend",
      "comment": "Sempet ada kendala kecil tapi langsung ditangani admin dengan cepat.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "21 May 2026",
      "daysAgo": 117
    },
    {
      "id": 93,
      "name": "Maya F.",
      "service": "Joki Rank Epic ke Legend",
      "comment": "Akun aman, gak ada masalah setelah selesai dikerjain. Puas sama hasilnya.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "19 May 2026",
      "daysAgo": 119
    },
    {
      "id": 62,
      "name": "Sinta R.",
      "service": "Joki Solo Rank Aman",
      "comment": "Harga worth it banget dibanding jasa joki lain, plus ada garansi juga.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "17 May 2026",
      "daysAgo": 121
    },
    {
      "id": 33,
      "name": "Krisna R.",
      "service": "Joki Solo Rank Aman",
      "comment": "Harga bersahabat buat mahasiswa kayak aku, kualitas tetap oke.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "16 May 2026",
      "daysAgo": 122
    },
    {
      "id": 43,
      "name": "Dewi D.",
      "service": "Joki Legend ke Mythic",
      "comment": "Garansi winrate beneran ditepati, gak php sama sekali.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "7 May 2026",
      "daysAgo": 131
    },
    {
      "id": 26,
      "name": "Fajar S.",
      "service": "Joki Solo Rank Aman",
      "comment": "Recommended buat yang sibuk tapi masih pengen naik rank tiap season.",
      "badge": "Terverifikasi",
      "rating": 3,
      "date": "1 May 2026",
      "daysAgo": 137
    },
    {
      "id": 65,
      "name": "Zahra K.",
      "service": "Joki Gendong VIP Squad",
      "comment": "Garansi winrate beneran ditepati, gak php sama sekali.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "30 Apr 2026",
      "daysAgo": 138
    },
    {
      "id": 69,
      "name": "Rian P.",
      "service": "Joki Solo Rank Aman",
      "comment": "Push rank sambil kerja jadi gak kepikiran lagi, tinggal terima beres.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "30 Apr 2026",
      "daysAgo": 138
    },
    {
      "id": 86,
      "name": "Vicky K.",
      "service": "Joki Winrate Fanny 85%",
      "comment": "Progress bisa dipantau terus, jadi tenang nungguin akun selesai dikerjain.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "29 Apr 2026",
      "daysAgo": 139
    },
    {
      "id": 37,
      "name": "Sinta H.",
      "service": "Joki Winrate Fanny 85%",
      "comment": "Akun aman, gak ada masalah setelah selesai dikerjain. Puas sama hasilnya.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "27 Apr 2026",
      "daysAgo": 141
    },
    {
      "id": 83,
      "name": "Pandu B.",
      "service": "Joki Solo Rank Aman",
      "comment": "Garansi winrate beneran ditepati, gak php sama sekali.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "27 Apr 2026",
      "daysAgo": 141
    },
    {
      "id": 51,
      "name": "Krisna L.",
      "service": "Push 25 Bintang Mythic",
      "comment": "Bakal jadi langganan tetap tiap mau push rank akhir season.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "26 Apr 2026",
      "daysAgo": 142
    },
    {
      "id": 15,
      "name": "Reza H.",
      "service": "Joki Placement 10 Match",
      "comment": "Progress bisa dipantau terus, jadi tenang nungguin akun selesai dikerjain.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "24 Apr 2026",
      "daysAgo": 144
    },
    {
      "id": 59,
      "name": "Yusuf M.",
      "service": "Paket Kilat 5 Bintang",
      "comment": "Udah langganan dari season lalu, selalu puas sama kerjaan tim Rookie Joki.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "24 Apr 2026",
      "daysAgo": 144
    },
    {
      "id": 25,
      "name": "Zaki G.",
      "service": "Push 25 Bintang Mythic",
      "comment": "Udah langganan dari season lalu, selalu puas sama kerjaan tim Rookie Joki.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "22 Apr 2026",
      "daysAgo": 146
    },
    {
      "id": 78,
      "name": "Galih D.",
      "service": "Push Mythic Glory",
      "comment": "Squad-nya solid, mabar bareng jadi lebih seru dan hasilnya maksimal.",
      "badge": "Pembeli Asli",
      "rating": 4,
      "date": "20 Apr 2026",
      "daysAgo": 148
    },
    {
      "id": 57,
      "name": "Eka G.",
      "service": "Joki Solo Rank Aman",
      "comment": "Awalnya ragu tapi ternyata beneran aman dan hasilnya sesuai janji.",
      "badge": "Terverifikasi",
      "rating": 4,
      "date": "18 Apr 2026",
      "daysAgo": 150
    },
    {
      "id": 92,
      "name": "Wulan R.",
      "service": "Joki Legend ke Mythic",
      "comment": "Awalnya ragu tapi ternyata beneran aman dan hasilnya sesuai janji.",
      "badge": "Terverifikasi",
      "rating": 4,
      "date": "16 Apr 2026",
      "daysAgo": 152
    },
    {
      "id": 27,
      "name": "Zahra R.",
      "service": "Joki Placement 10 Match",
      "comment": "Recommended buat yang sibuk tapi masih pengen naik rank tiap season.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "12 Apr 2026",
      "daysAgo": 156
    },
    {
      "id": 99,
      "name": "Maya M.",
      "service": "Joki Legend ke Mythic",
      "comment": "Progress bisa dipantau terus, jadi tenang nungguin akun selesai dikerjain.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "12 Apr 2026",
      "daysAgo": 156
    },
    {
      "id": 48,
      "name": "Reza K.",
      "service": "Joki Legend ke Mythic",
      "comment": "Pertama kali coba jasa joki dan langsung cocok, bakal order lagi nanti.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "8 Apr 2026",
      "daysAgo": 160
    },
    {
      "id": 3,
      "name": "Nanda M.",
      "service": "Boost Winrate Hero Core",
      "comment": "Bakal jadi langganan tetap tiap mau push rank akhir season.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "1 Apr 2026",
      "daysAgo": 167
    },
    {
      "id": 70,
      "name": "Tegar L.",
      "service": "Joki Solo Rank Aman",
      "comment": "Fast respon admin pas nanya-nanya sebelum order, mantap pelayanannya.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "28 Mar 2026",
      "daysAgo": 171
    },
    {
      "id": 71,
      "name": "Wahyu D.",
      "service": "Joki Gendong VIP Squad",
      "comment": "Harga worth it banget dibanding jasa joki lain, plus ada garansi juga.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "28 Mar 2026",
      "daysAgo": 171
    },
    {
      "id": 72,
      "name": "Chandra A.",
      "service": "Joki Grandmaster ke Epic",
      "comment": "Selesai lebih cepat dari estimasi, worker jago banget mainnya.",
      "badge": "Terverifikasi",
      "rating": 5,
      "date": "28 Mar 2026",
      "daysAgo": 171
    },
    {
      "id": 28,
      "name": "Dian M.",
      "service": "Boost Winrate Hero Core",
      "comment": "Fast respon admin pas nanya-nanya sebelum order, mantap pelayanannya.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "27 Mar 2026",
      "daysAgo": 172
    },
    {
      "id": 47,
      "name": "Salsa L.",
      "service": "Joki Gendong VIP Squad",
      "comment": "Udah langganan dari season lalu, selalu puas sama kerjaan tim Rookie Joki.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "27 Mar 2026",
      "daysAgo": 172
    },
    {
      "id": 80,
      "name": "Reza L.",
      "service": "Joki Rank Epic ke Legend",
      "comment": "Harga worth it banget dibanding jasa joki lain, plus ada garansi juga.",
      "badge": "Pembeli Asli",
      "rating": 5,
      "date": "20 Mar 2026",
      "daysAgo": 179
    }
  ],
  "leaderboard": [
    {
      "rank": 1,
      "name": "Phantom_Mythic86",
      "wr": 99.4,
      "match": 456,
      "badge": "Pro Glory"
    },
    {
      "rank": 2,
      "name": "Viper_Mythic88",
      "wr": 99.3,
      "match": 453,
      "badge": "Pro Mythic"
    },
    {
      "rank": 3,
      "name": "Omega_Glory76",
      "wr": 99.2,
      "match": 464,
      "badge": "Pro Immortal"
    },
    {
      "rank": 4,
      "name": "Nexus_X54",
      "wr": 99.1,
      "match": 448,
      "badge": "Pro Mythic"
    },
    {
      "rank": 5,
      "name": "Rookie_Prime62",
      "wr": 98.7,
      "match": 466,
      "badge": "Top Worker"
    },
    {
      "rank": 6,
      "name": "Spectre_God55",
      "wr": 98.7,
      "match": 456,
      "badge": "Pro Mythic"
    },
    {
      "rank": 7,
      "name": "Blitz_X61",
      "wr": 98.7,
      "match": 462,
      "badge": "Pro Mythic"
    },
    {
      "rank": 8,
      "name": "Nexus_King11",
      "wr": 98.6,
      "match": 454,
      "badge": "Top Worker"
    },
    {
      "rank": 9,
      "name": "Blitz_Mythic85",
      "wr": 98.6,
      "match": 445,
      "badge": "Pro Mythic"
    },
    {
      "rank": 10,
      "name": "Kaiser_Zero27",
      "wr": 98.5,
      "match": 449,
      "badge": "Pro Mythic"
    },
    {
      "rank": 11,
      "name": "Blitz_Master71",
      "wr": 98.2,
      "match": 462,
      "badge": "Pro Immortal"
    },
    {
      "rank": 12,
      "name": "Zeta_Prime62",
      "wr": 98.4,
      "match": 447,
      "badge": "Top Worker"
    },
    {
      "rank": 13,
      "name": "Slayer_Zero57",
      "wr": 98.5,
      "match": 444,
      "badge": "Pro Glory"
    },
    {
      "rank": 14,
      "name": "Shadow_King39",
      "wr": 98.4,
      "match": 448,
      "badge": "Pro Mythic"
    },
    {
      "rank": 15,
      "name": "Shadow_X42",
      "wr": 98.1,
      "match": 450,
      "badge": "Pro Mythic"
    },
    {
      "rank": 16,
      "name": "Phantom_King15",
      "wr": 98.2,
      "match": 446,
      "badge": "Pro Glory"
    },
    {
      "rank": 17,
      "name": "Zeta_King94",
      "wr": 98.1,
      "match": 454,
      "badge": "Pro Mythic"
    },
    {
      "rank": 18,
      "name": "Viper_King37",
      "wr": 97.9,
      "match": 442,
      "badge": "Pro Immortal"
    },
    {
      "rank": 19,
      "name": "Spectre_X16",
      "wr": 97.8,
      "match": 458,
      "badge": "Pro Mythic"
    },
    {
      "rank": 20,
      "name": "Spectre_God81",
      "wr": 98,
      "match": 447,
      "badge": "Pro Immortal"
    },
    {
      "rank": 21,
      "name": "Blitz_Master60",
      "wr": 97.8,
      "match": 444,
      "badge": "Pro Immortal"
    },
    {
      "rank": 22,
      "name": "Phantom_Zero14",
      "wr": 97.9,
      "match": 444,
      "badge": "Pro Immortal"
    },
    {
      "rank": 23,
      "name": "Blitz_Glory87",
      "wr": 97.4,
      "match": 439,
      "badge": "Pro Mythic"
    },
    {
      "rank": 24,
      "name": "Viper_King15",
      "wr": 97.6,
      "match": 443,
      "badge": "Pro Glory"
    },
    {
      "rank": 25,
      "name": "Alpha_X48",
      "wr": 97.5,
      "match": 443,
      "badge": "Top Worker"
    },
    {
      "rank": 26,
      "name": "Phantom_Mythic79",
      "wr": 97.2,
      "match": 453,
      "badge": "Pro Immortal"
    },
    {
      "rank": 27,
      "name": "Alpha_King80",
      "wr": 97.2,
      "match": 447,
      "badge": "Pro Glory"
    },
    {
      "rank": 28,
      "name": "Zeta_God70",
      "wr": 97.1,
      "match": 433,
      "badge": "Top Worker"
    },
    {
      "rank": 29,
      "name": "Spectre_Mythic60",
      "wr": 97.1,
      "match": 437,
      "badge": "Pro Mythic"
    },
    {
      "rank": 30,
      "name": "Spectre_Zero9",
      "wr": 97.2,
      "match": 450,
      "badge": "Pro Glory"
    },
    {
      "rank": 31,
      "name": "Shadow_MLBB69",
      "wr": 96.9,
      "match": 434,
      "badge": "Pro Mythic"
    },
    {
      "rank": 32,
      "name": "Omega_God9",
      "wr": 96.8,
      "match": 446,
      "badge": "Pro Mythic"
    },
    {
      "rank": 33,
      "name": "Apex_MLBB59",
      "wr": 97,
      "match": 444,
      "badge": "Pro Mythic"
    },
    {
      "rank": 34,
      "name": "Hyper_X63",
      "wr": 96.8,
      "match": 441,
      "badge": "Top Worker"
    },
    {
      "rank": 35,
      "name": "Spectre_Exa77",
      "wr": 96.7,
      "match": 430,
      "badge": "Pro Immortal"
    },
    {
      "rank": 36,
      "name": "Alpha_Glory34",
      "wr": 96.8,
      "match": 443,
      "badge": "Pro Glory"
    },
    {
      "rank": 37,
      "name": "Apex_X83",
      "wr": 96.6,
      "match": 433,
      "badge": "Top Worker"
    },
    {
      "rank": 38,
      "name": "Slayer_Zero11",
      "wr": 96.6,
      "match": 435,
      "badge": "Pro Mythic"
    },
    {
      "rank": 39,
      "name": "Slayer_MLBB20",
      "wr": 96.4,
      "match": 440,
      "badge": "Pro Mythic"
    },
    {
      "rank": 40,
      "name": "Slayer_Prime97",
      "wr": 96.5,
      "match": 435,
      "badge": "Pro Mythic"
    },
    {
      "rank": 41,
      "name": "Phantom_Exa14",
      "wr": 96.6,
      "match": 433,
      "badge": "Pro Immortal"
    },
    {
      "rank": 42,
      "name": "Slayer_X59",
      "wr": 96.3,
      "match": 428,
      "badge": "Pro Mythic"
    },
    {
      "rank": 43,
      "name": "Blitz_Zero80",
      "wr": 96.2,
      "match": 425,
      "badge": "Pro Mythic"
    },
    {
      "rank": 44,
      "name": "Hyper_God36",
      "wr": 96.1,
      "match": 437,
      "badge": "Pro Immortal"
    },
    {
      "rank": 45,
      "name": "Rookie_Glory77",
      "wr": 96.2,
      "match": 437,
      "badge": "Pro Mythic"
    },
    {
      "rank": 46,
      "name": "Hyper_Pro70",
      "wr": 96,
      "match": 426,
      "badge": "Pro Immortal"
    },
    {
      "rank": 47,
      "name": "Apex_MLBB82",
      "wr": 96.1,
      "match": 431,
      "badge": "Pro Mythic"
    },
    {
      "rank": 48,
      "name": "Hyper_Master53",
      "wr": 96.1,
      "match": 440,
      "badge": "Pro Glory"
    },
    {
      "rank": 49,
      "name": "Apex_X18",
      "wr": 95.8,
      "match": 439,
      "badge": "Pro Glory"
    },
    {
      "rank": 50,
      "name": "Omega_MLBB35",
      "wr": 95.9,
      "match": 437,
      "badge": "Pro Mythic"
    },
    {
      "rank": 51,
      "name": "Alpha_X34",
      "wr": 95.8,
      "match": 425,
      "badge": "Pro Mythic"
    },
    {
      "rank": 52,
      "name": "Omega_Mythic74",
      "wr": 95.9,
      "match": 428,
      "badge": "Pro Glory"
    },
    {
      "rank": 53,
      "name": "Apex_X61",
      "wr": 95.5,
      "match": 429,
      "badge": "Top Worker"
    },
    {
      "rank": 54,
      "name": "Apex_Exa24",
      "wr": 95.7,
      "match": 422,
      "badge": "Top Worker"
    },
    {
      "rank": 55,
      "name": "Zeta_Prime5",
      "wr": 95.3,
      "match": 426,
      "badge": "Top Worker"
    },
    {
      "rank": 56,
      "name": "Shadow_Glory83",
      "wr": 95.6,
      "match": 426,
      "badge": "Pro Immortal"
    },
    {
      "rank": 57,
      "name": "Kaiser_X75",
      "wr": 95.2,
      "match": 417,
      "badge": "Top Worker"
    },
    {
      "rank": 58,
      "name": "Viper_X58",
      "wr": 94.9,
      "match": 418,
      "badge": "Pro Glory"
    },
    {
      "rank": 59,
      "name": "Viper_Zero33",
      "wr": 95,
      "match": 428,
      "badge": "Pro Immortal"
    },
    {
      "rank": 60,
      "name": "Omega_Exa86",
      "wr": 95.2,
      "match": 421,
      "badge": "Pro Mythic"
    },
    {
      "rank": 61,
      "name": "Slayer_Zero69",
      "wr": 94.7,
      "match": 414,
      "badge": "Pro Mythic"
    },
    {
      "rank": 62,
      "name": "Zeta_MLBB55",
      "wr": 95.1,
      "match": 428,
      "badge": "Pro Immortal"
    },
    {
      "rank": 63,
      "name": "Apex_God88",
      "wr": 94.7,
      "match": 412,
      "badge": "Pro Mythic"
    },
    {
      "rank": 64,
      "name": "Alpha_Pro37",
      "wr": 94.7,
      "match": 420,
      "badge": "Pro Glory"
    },
    {
      "rank": 65,
      "name": "Hyper_Prime72",
      "wr": 94.8,
      "match": 414,
      "badge": "Pro Glory"
    },
    {
      "rank": 66,
      "name": "Viper_Mythic48",
      "wr": 94.7,
      "match": 415,
      "badge": "Pro Glory"
    },
    {
      "rank": 67,
      "name": "Zeta_Zero81",
      "wr": 94.4,
      "match": 414,
      "badge": "Pro Immortal"
    },
    {
      "rank": 68,
      "name": "Alpha_Zero36",
      "wr": 94.6,
      "match": 412,
      "badge": "Top Worker"
    },
    {
      "rank": 69,
      "name": "Nexus_Mythic38",
      "wr": 94.5,
      "match": 417,
      "badge": "Pro Mythic"
    },
    {
      "rank": 70,
      "name": "Apex_Master25",
      "wr": 94.6,
      "match": 425,
      "badge": "Pro Immortal"
    },
    {
      "rank": 71,
      "name": "Zeta_Prime73",
      "wr": 94.2,
      "match": 413,
      "badge": "Pro Mythic"
    },
    {
      "rank": 72,
      "name": "Rookie_Glory50",
      "wr": 94.1,
      "match": 418,
      "badge": "Pro Immortal"
    },
    {
      "rank": 73,
      "name": "Blitz_Zero36",
      "wr": 94.3,
      "match": 410,
      "badge": "Pro Mythic"
    },
    {
      "rank": 74,
      "name": "Zeta_Glory24",
      "wr": 94.1,
      "match": 419,
      "badge": "Pro Glory"
    },
    {
      "rank": 75,
      "name": "Slayer_MLBB80",
      "wr": 94.1,
      "match": 411,
      "badge": "Top Worker"
    },
    {
      "rank": 76,
      "name": "Rookie_Mythic46",
      "wr": 94,
      "match": 406,
      "badge": "Pro Mythic"
    },
    {
      "rank": 77,
      "name": "Nexus_Prime22",
      "wr": 93.7,
      "match": 419,
      "badge": "Pro Mythic"
    },
    {
      "rank": 78,
      "name": "Hyper_X34",
      "wr": 94,
      "match": 408,
      "badge": "Top Worker"
    },
    {
      "rank": 79,
      "name": "Alpha_Master95",
      "wr": 93.9,
      "match": 418,
      "badge": "Top Worker"
    },
    {
      "rank": 80,
      "name": "Viper_God96",
      "wr": 93.9,
      "match": 419,
      "badge": "Top Worker"
    },
    {
      "rank": 81,
      "name": "Omega_X46",
      "wr": 93.4,
      "match": 409,
      "badge": "Pro Mythic"
    },
    {
      "rank": 82,
      "name": "Hyper_MLBB58",
      "wr": 93.4,
      "match": 415,
      "badge": "Pro Mythic"
    },
    {
      "rank": 83,
      "name": "Blitz_Prime81",
      "wr": 93.7,
      "match": 402,
      "badge": "Pro Glory"
    },
    {
      "rank": 84,
      "name": "Apex_Pro79",
      "wr": 93.6,
      "match": 410,
      "badge": "Pro Glory"
    },
    {
      "rank": 85,
      "name": "Slayer_MLBB81",
      "wr": 93.5,
      "match": 417,
      "badge": "Pro Mythic"
    },
    {
      "rank": 86,
      "name": "Slayer_Prime14",
      "wr": 93,
      "match": 417,
      "badge": "Pro Mythic"
    },
    {
      "rank": 87,
      "name": "Apex_MLBB12",
      "wr": 93,
      "match": 408,
      "badge": "Top Worker"
    },
    {
      "rank": 88,
      "name": "Apex_Exa85",
      "wr": 93.3,
      "match": 411,
      "badge": "Top Worker"
    },
    {
      "rank": 89,
      "name": "Blitz_God53",
      "wr": 93.1,
      "match": 413,
      "badge": "Top Worker"
    },
    {
      "rank": 90,
      "name": "Phantom_Pro88",
      "wr": 92.9,
      "match": 404,
      "badge": "Pro Glory"
    },
    {
      "rank": 91,
      "name": "Omega_Exa12",
      "wr": 93.1,
      "match": 402,
      "badge": "Pro Mythic"
    },
    {
      "rank": 92,
      "name": "Rookie_Prime35",
      "wr": 92.7,
      "match": 397,
      "badge": "Top Worker"
    },
    {
      "rank": 93,
      "name": "Viper_Glory27",
      "wr": 92.8,
      "match": 406,
      "badge": "Pro Immortal"
    },
    {
      "rank": 94,
      "name": "Rookie_Exa31",
      "wr": 92.9,
      "match": 409,
      "badge": "Pro Glory"
    },
    {
      "rank": 95,
      "name": "Viper_X26",
      "wr": 92.6,
      "match": 409,
      "badge": "Pro Glory"
    },
    {
      "rank": 96,
      "name": "Nexus_God76",
      "wr": 92.3,
      "match": 409,
      "badge": "Pro Glory"
    },
    {
      "rank": 97,
      "name": "Kaiser_X32",
      "wr": 92.6,
      "match": 393,
      "badge": "Pro Immortal"
    },
    {
      "rank": 98,
      "name": "Kaiser_Pro45",
      "wr": 92.5,
      "match": 395,
      "badge": "Pro Mythic"
    },
    {
      "rank": 99,
      "name": "Rookie_God33",
      "wr": 92.1,
      "match": 405,
      "badge": "Pro Immortal"
    },
    {
      "rank": 100,
      "name": "Spectre_MLBB60",
      "wr": 92.2,
      "match": 397,
      "badge": "Pro Immortal"
    },
    {
      "rank": 101,
      "name": "Apex_X28",
      "wr": 92.4,
      "match": 390,
      "badge": "Pro Mythic"
    },
    {
      "rank": 102,
      "name": "Apex_Glory3",
      "wr": 91.9,
      "match": 398,
      "badge": "Top Worker"
    },
    {
      "rank": 103,
      "name": "Shadow_Glory13",
      "wr": 92,
      "match": 406,
      "badge": "Pro Immortal"
    },
    {
      "rank": 104,
      "name": "Viper_Exa77",
      "wr": 91.8,
      "match": 390,
      "badge": "Pro Mythic"
    },
    {
      "rank": 105,
      "name": "Shadow_Mythic67",
      "wr": 91.8,
      "match": 397,
      "badge": "Top Worker"
    },
    {
      "rank": 106,
      "name": "Viper_MLBB83",
      "wr": 91.9,
      "match": 401,
      "badge": "Pro Glory"
    },
    {
      "rank": 107,
      "name": "Shadow_Zero29",
      "wr": 91.7,
      "match": 402,
      "badge": "Top Worker"
    },
    {
      "rank": 108,
      "name": "Shadow_MLBB40",
      "wr": 91.7,
      "match": 398,
      "badge": "Pro Mythic"
    },
    {
      "rank": 109,
      "name": "Kaiser_Glory60",
      "wr": 91.4,
      "match": 401,
      "badge": "Pro Immortal"
    },
    {
      "rank": 110,
      "name": "Shadow_MLBB95",
      "wr": 91.7,
      "match": 400,
      "badge": "Pro Immortal"
    },
    {
      "rank": 111,
      "name": "Blitz_X71",
      "wr": 91.4,
      "match": 385,
      "badge": "Pro Mythic"
    },
    {
      "rank": 112,
      "name": "Omega_Glory96",
      "wr": 91.4,
      "match": 401,
      "badge": "Pro Immortal"
    },
    {
      "rank": 113,
      "name": "Phantom_Mythic39",
      "wr": 91.3,
      "match": 393,
      "badge": "Pro Glory"
    },
    {
      "rank": 114,
      "name": "Kaiser_Glory61",
      "wr": 91.1,
      "match": 383,
      "badge": "Pro Mythic"
    },
    {
      "rank": 115,
      "name": "Viper_Master73",
      "wr": 91.1,
      "match": 389,
      "badge": "Pro Immortal"
    },
    {
      "rank": 116,
      "name": "Blitz_Glory88",
      "wr": 91,
      "match": 384,
      "badge": "Pro Mythic"
    },
    {
      "rank": 117,
      "name": "Nexus_Exa0",
      "wr": 90.9,
      "match": 382,
      "badge": "Top Worker"
    },
    {
      "rank": 118,
      "name": "Viper_God94",
      "wr": 91.1,
      "match": 379,
      "badge": "Pro Glory"
    },
    {
      "rank": 119,
      "name": "Shadow_Prime58",
      "wr": 90.8,
      "match": 386,
      "badge": "Pro Mythic"
    },
    {
      "rank": 120,
      "name": "Alpha_Mythic76",
      "wr": 90.6,
      "match": 379,
      "badge": "Pro Glory"
    },
    {
      "rank": 121,
      "name": "Alpha_Mythic6",
      "wr": 90.9,
      "match": 382,
      "badge": "Top Worker"
    },
    {
      "rank": 122,
      "name": "Apex_Mythic56",
      "wr": 90.7,
      "match": 381,
      "badge": "Pro Immortal"
    },
    {
      "rank": 123,
      "name": "Nexus_Prime14",
      "wr": 90.5,
      "match": 389,
      "badge": "Top Worker"
    },
    {
      "rank": 124,
      "name": "Hyper_Glory39",
      "wr": 90.3,
      "match": 383,
      "badge": "Pro Immortal"
    },
    {
      "rank": 125,
      "name": "Rookie_King38",
      "wr": 90.7,
      "match": 390,
      "badge": "Pro Mythic"
    },
    {
      "rank": 126,
      "name": "Phantom_Exa15",
      "wr": 90.2,
      "match": 389,
      "badge": "Pro Glory"
    },
    {
      "rank": 127,
      "name": "Kaiser_Prime68",
      "wr": 90.5,
      "match": 383,
      "badge": "Pro Mythic"
    },
    {
      "rank": 128,
      "name": "Viper_Prime94",
      "wr": 90.1,
      "match": 373,
      "badge": "Pro Immortal"
    },
    {
      "rank": 129,
      "name": "Omega_Exa73",
      "wr": 90.2,
      "match": 380,
      "badge": "Top Worker"
    },
    {
      "rank": 130,
      "name": "Phantom_MLBB51",
      "wr": 89.9,
      "match": 378,
      "badge": "Top Worker"
    },
    {
      "rank": 131,
      "name": "Omega_Exa11",
      "wr": 90,
      "match": 373,
      "badge": "Top Worker"
    },
    {
      "rank": 132,
      "name": "Blitz_Prime67",
      "wr": 89.8,
      "match": 388,
      "badge": "Pro Mythic"
    },
    {
      "rank": 133,
      "name": "Zeta_Exa21",
      "wr": 89.7,
      "match": 382,
      "badge": "Pro Glory"
    },
    {
      "rank": 134,
      "name": "Alpha_Exa44",
      "wr": 90,
      "match": 385,
      "badge": "Pro Glory"
    },
    {
      "rank": 135,
      "name": "Zeta_MLBB18",
      "wr": 89.7,
      "match": 372,
      "badge": "Pro Glory"
    },
    {
      "rank": 136,
      "name": "Alpha_Glory9",
      "wr": 89.6,
      "match": 383,
      "badge": "Top Worker"
    },
    {
      "rank": 137,
      "name": "Apex_Mythic97",
      "wr": 89.7,
      "match": 381,
      "badge": "Pro Mythic"
    },
    {
      "rank": 138,
      "name": "Omega_Glory40",
      "wr": 89.4,
      "match": 368,
      "badge": "Top Worker"
    },
    {
      "rank": 139,
      "name": "Slayer_Master35",
      "wr": 89.6,
      "match": 373,
      "badge": "Pro Immortal"
    },
    {
      "rank": 140,
      "name": "Phantom_Zero57",
      "wr": 89.2,
      "match": 373,
      "badge": "Pro Mythic"
    },
    {
      "rank": 141,
      "name": "Viper_Glory11",
      "wr": 89.4,
      "match": 375,
      "badge": "Top Worker"
    },
    {
      "rank": 142,
      "name": "Blitz_X94",
      "wr": 89.5,
      "match": 373,
      "badge": "Pro Glory"
    },
    {
      "rank": 143,
      "name": "Nexus_Mythic60",
      "wr": 89.2,
      "match": 383,
      "badge": "Top Worker"
    },
    {
      "rank": 144,
      "name": "Viper_Exa91",
      "wr": 89,
      "match": 376,
      "badge": "Pro Immortal"
    },
    {
      "rank": 145,
      "name": "Zeta_Zero56",
      "wr": 89.1,
      "match": 375,
      "badge": "Pro Mythic"
    },
    {
      "rank": 146,
      "name": "Nexus_Master49",
      "wr": 89,
      "match": 369,
      "badge": "Pro Immortal"
    },
    {
      "rank": 147,
      "name": "Alpha_Glory82",
      "wr": 88.9,
      "match": 368,
      "badge": "Top Worker"
    },
    {
      "rank": 148,
      "name": "Phantom_Master92",
      "wr": 89.1,
      "match": 380,
      "badge": "Pro Glory"
    },
    {
      "rank": 149,
      "name": "Nexus_MLBB74",
      "wr": 88.9,
      "match": 378,
      "badge": "Pro Mythic"
    },
    {
      "rank": 150,
      "name": "Slayer_Glory50",
      "wr": 88.6,
      "match": 374,
      "badge": "Pro Immortal"
    },
    {
      "rank": 151,
      "name": "Phantom_X48",
      "wr": 88.8,
      "match": 365,
      "badge": "Pro Glory"
    },
    {
      "rank": 152,
      "name": "Slayer_Glory67",
      "wr": 88.4,
      "match": 372,
      "badge": "Pro Mythic"
    },
    {
      "rank": 153,
      "name": "Rookie_Exa39",
      "wr": 88.4,
      "match": 362,
      "badge": "Top Worker"
    },
    {
      "rank": 154,
      "name": "Zeta_King17",
      "wr": 88.3,
      "match": 363,
      "badge": "Pro Immortal"
    },
    {
      "rank": 155,
      "name": "Hyper_X94",
      "wr": 88.6,
      "match": 357,
      "badge": "Pro Mythic"
    },
    {
      "rank": 156,
      "name": "Alpha_Mythic16",
      "wr": 88.4,
      "match": 359,
      "badge": "Pro Glory"
    },
    {
      "rank": 157,
      "name": "Omega_Mythic21",
      "wr": 88.4,
      "match": 356,
      "badge": "Pro Mythic"
    },
    {
      "rank": 158,
      "name": "Slayer_King56",
      "wr": 88.2,
      "match": 370,
      "badge": "Top Worker"
    },
    {
      "rank": 159,
      "name": "Zeta_X30",
      "wr": 88,
      "match": 370,
      "badge": "Top Worker"
    },
    {
      "rank": 160,
      "name": "Omega_King47",
      "wr": 88.1,
      "match": 365,
      "badge": "Top Worker"
    },
    {
      "rank": 161,
      "name": "Apex_Master48",
      "wr": 88,
      "match": 361,
      "badge": "Pro Glory"
    },
    {
      "rank": 162,
      "name": "Omega_King77",
      "wr": 87.7,
      "match": 357,
      "badge": "Top Worker"
    },
    {
      "rank": 163,
      "name": "Omega_Exa70",
      "wr": 88.1,
      "match": 366,
      "badge": "Pro Immortal"
    },
    {
      "rank": 164,
      "name": "Phantom_MLBB97",
      "wr": 87.6,
      "match": 360,
      "badge": "Pro Glory"
    },
    {
      "rank": 165,
      "name": "Omega_Prime11",
      "wr": 87.9,
      "match": 355,
      "badge": "Top Worker"
    },
    {
      "rank": 166,
      "name": "Nexus_Pro53",
      "wr": 87.4,
      "match": 360,
      "badge": "Pro Glory"
    },
    {
      "rank": 167,
      "name": "Shadow_MLBB47",
      "wr": 87.4,
      "match": 356,
      "badge": "Pro Immortal"
    },
    {
      "rank": 168,
      "name": "Omega_Glory42",
      "wr": 87.6,
      "match": 351,
      "badge": "Pro Mythic"
    },
    {
      "rank": 169,
      "name": "Omega_Zero89",
      "wr": 87.6,
      "match": 363,
      "badge": "Top Worker"
    },
    {
      "rank": 170,
      "name": "Apex_Mythic0",
      "wr": 87.6,
      "match": 348,
      "badge": "Pro Glory"
    },
    {
      "rank": 171,
      "name": "Omega_God70",
      "wr": 87.5,
      "match": 359,
      "badge": "Top Worker"
    },
    {
      "rank": 172,
      "name": "Viper_Master30",
      "wr": 87.1,
      "match": 347,
      "badge": "Top Worker"
    },
    {
      "rank": 173,
      "name": "Slayer_Mythic58",
      "wr": 86.9,
      "match": 362,
      "badge": "Top Worker"
    },
    {
      "rank": 174,
      "name": "Blitz_X2",
      "wr": 87.1,
      "match": 357,
      "badge": "Pro Glory"
    },
    {
      "rank": 175,
      "name": "Phantom_Prime0",
      "wr": 87.1,
      "match": 349,
      "badge": "Top Worker"
    },
    {
      "rank": 176,
      "name": "Kaiser_Glory85",
      "wr": 86.7,
      "match": 363,
      "badge": "Pro Immortal"
    },
    {
      "rank": 177,
      "name": "Hyper_X64",
      "wr": 87,
      "match": 353,
      "badge": "Pro Immortal"
    },
    {
      "rank": 178,
      "name": "Shadow_Zero5",
      "wr": 86.9,
      "match": 362,
      "badge": "Pro Mythic"
    },
    {
      "rank": 179,
      "name": "Spectre_Pro45",
      "wr": 86.9,
      "match": 349,
      "badge": "Pro Immortal"
    },
    {
      "rank": 180,
      "name": "Alpha_Mythic94",
      "wr": 86.8,
      "match": 344,
      "badge": "Pro Mythic"
    },
    {
      "rank": 181,
      "name": "Hyper_Exa82",
      "wr": 86.4,
      "match": 356,
      "badge": "Top Worker"
    },
    {
      "rank": 182,
      "name": "Spectre_Zero80",
      "wr": 86.4,
      "match": 343,
      "badge": "Top Worker"
    },
    {
      "rank": 183,
      "name": "Rookie_Master25",
      "wr": 86.2,
      "match": 344,
      "badge": "Pro Immortal"
    },
    {
      "rank": 184,
      "name": "Nexus_Master65",
      "wr": 86.3,
      "match": 355,
      "badge": "Top Worker"
    },
    {
      "rank": 185,
      "name": "Phantom_Pro96",
      "wr": 86.4,
      "match": 344,
      "badge": "Pro Immortal"
    },
    {
      "rank": 186,
      "name": "Omega_Glory42",
      "wr": 86.1,
      "match": 354,
      "badge": "Top Worker"
    },
    {
      "rank": 187,
      "name": "Shadow_Zero49",
      "wr": 86.1,
      "match": 341,
      "badge": "Top Worker"
    },
    {
      "rank": 188,
      "name": "Nexus_X34",
      "wr": 86.2,
      "match": 351,
      "badge": "Pro Immortal"
    },
    {
      "rank": 189,
      "name": "Shadow_Mythic23",
      "wr": 86,
      "match": 343,
      "badge": "Pro Immortal"
    },
    {
      "rank": 190,
      "name": "Nexus_Glory37",
      "wr": 85.9,
      "match": 348,
      "badge": "Top Worker"
    },
    {
      "rank": 191,
      "name": "Kaiser_Zero44",
      "wr": 85.9,
      "match": 349,
      "badge": "Pro Mythic"
    },
    {
      "rank": 192,
      "name": "Blitz_Prime35",
      "wr": 85.9,
      "match": 350,
      "badge": "Pro Immortal"
    },
    {
      "rank": 193,
      "name": "Viper_Glory81",
      "wr": 85.7,
      "match": 344,
      "badge": "Pro Glory"
    },
    {
      "rank": 194,
      "name": "Rookie_God77",
      "wr": 85.8,
      "match": 342,
      "badge": "Pro Glory"
    },
    {
      "rank": 195,
      "name": "Viper_King82",
      "wr": 85.5,
      "match": 340,
      "badge": "Pro Immortal"
    },
    {
      "rank": 196,
      "name": "Blitz_God86",
      "wr": 85.5,
      "match": 339,
      "badge": "Top Worker"
    },
    {
      "rank": 197,
      "name": "Alpha_MLBB73",
      "wr": 85.3,
      "match": 339,
      "badge": "Pro Mythic"
    },
    {
      "rank": 198,
      "name": "Slayer_Master31",
      "wr": 85.6,
      "match": 331,
      "badge": "Pro Glory"
    },
    {
      "rank": 199,
      "name": "Apex_X49",
      "wr": 85.5,
      "match": 332,
      "badge": "Pro Mythic"
    },
    {
      "rank": 200,
      "name": "Spectre_Zero27",
      "wr": 85.5,
      "match": 335,
      "badge": "Top Worker"
    },
    {
      "rank": 201,
      "name": "Zeta_MLBB17",
      "wr": 85.4,
      "match": 338,
      "badge": "Top Worker"
    },
    {
      "rank": 202,
      "name": "Viper_Glory40",
      "wr": 85.2,
      "match": 342,
      "badge": "Pro Mythic"
    },
    {
      "rank": 203,
      "name": "Phantom_God91",
      "wr": 85.1,
      "match": 342,
      "badge": "Pro Glory"
    },
    {
      "rank": 204,
      "name": "Alpha_Exa65",
      "wr": 84.8,
      "match": 347,
      "badge": "Pro Glory"
    },
    {
      "rank": 205,
      "name": "Zeta_Zero3",
      "wr": 84.8,
      "match": 338,
      "badge": "Top Worker"
    },
    {
      "rank": 206,
      "name": "Alpha_X16",
      "wr": 84.9,
      "match": 328,
      "badge": "Pro Mythic"
    },
    {
      "rank": 207,
      "name": "Shadow_Zero67",
      "wr": 84.7,
      "match": 333,
      "badge": "Pro Immortal"
    },
    {
      "rank": 208,
      "name": "Kaiser_Exa82",
      "wr": 84.5,
      "match": 334,
      "badge": "Pro Mythic"
    },
    {
      "rank": 209,
      "name": "Kaiser_X81",
      "wr": 84.7,
      "match": 339,
      "badge": "Pro Glory"
    },
    {
      "rank": 210,
      "name": "Shadow_X7",
      "wr": 84.7,
      "match": 334,
      "badge": "Pro Mythic"
    },
    {
      "rank": 211,
      "name": "Kaiser_God41",
      "wr": 84.7,
      "match": 327,
      "badge": "Pro Mythic"
    },
    {
      "rank": 212,
      "name": "Omega_MLBB32",
      "wr": 84.3,
      "match": 341,
      "badge": "Pro Mythic"
    },
    {
      "rank": 213,
      "name": "Kaiser_Glory38",
      "wr": 84.4,
      "match": 324,
      "badge": "Pro Glory"
    },
    {
      "rank": 214,
      "name": "Blitz_Mythic19",
      "wr": 84.1,
      "match": 334,
      "badge": "Pro Mythic"
    },
    {
      "rank": 215,
      "name": "Omega_Mythic5",
      "wr": 84.4,
      "match": 321,
      "badge": "Pro Immortal"
    },
    {
      "rank": 216,
      "name": "Slayer_Mythic33",
      "wr": 84.2,
      "match": 335,
      "badge": "Top Worker"
    },
    {
      "rank": 217,
      "name": "Blitz_Glory3",
      "wr": 84.1,
      "match": 332,
      "badge": "Pro Mythic"
    },
    {
      "rank": 218,
      "name": "Slayer_Master61",
      "wr": 83.9,
      "match": 335,
      "badge": "Top Worker"
    },
    {
      "rank": 219,
      "name": "Phantom_Zero9",
      "wr": 84,
      "match": 321,
      "badge": "Top Worker"
    },
    {
      "rank": 220,
      "name": "Apex_Zero26",
      "wr": 83.8,
      "match": 320,
      "badge": "Pro Mythic"
    },
    {
      "rank": 221,
      "name": "Spectre_Exa51",
      "wr": 83.6,
      "match": 324,
      "badge": "Pro Immortal"
    },
    {
      "rank": 222,
      "name": "Nexus_King59",
      "wr": 83.5,
      "match": 325,
      "badge": "Pro Glory"
    },
    {
      "rank": 223,
      "name": "Viper_Pro37",
      "wr": 83.9,
      "match": 333,
      "badge": "Top Worker"
    },
    {
      "rank": 224,
      "name": "Zeta_God41",
      "wr": 83.8,
      "match": 330,
      "badge": "Pro Glory"
    },
    {
      "rank": 225,
      "name": "Alpha_God63",
      "wr": 83.7,
      "match": 324,
      "badge": "Pro Mythic"
    },
    {
      "rank": 226,
      "name": "Apex_Pro11",
      "wr": 83.7,
      "match": 324,
      "badge": "Pro Glory"
    },
    {
      "rank": 227,
      "name": "Zeta_Mythic45",
      "wr": 83.1,
      "match": 319,
      "badge": "Top Worker"
    },
    {
      "rank": 228,
      "name": "Phantom_X1",
      "wr": 83.5,
      "match": 321,
      "badge": "Pro Mythic"
    },
    {
      "rank": 229,
      "name": "Spectre_Exa97",
      "wr": 83.2,
      "match": 313,
      "badge": "Pro Immortal"
    },
    {
      "rank": 230,
      "name": "Blitz_X24",
      "wr": 83.1,
      "match": 317,
      "badge": "Top Worker"
    },
    {
      "rank": 231,
      "name": "Hyper_Zero97",
      "wr": 83.1,
      "match": 327,
      "badge": "Pro Immortal"
    },
    {
      "rank": 232,
      "name": "Kaiser_MLBB50",
      "wr": 82.9,
      "match": 330,
      "badge": "Pro Mythic"
    },
    {
      "rank": 233,
      "name": "Alpha_God25",
      "wr": 83,
      "match": 318,
      "badge": "Pro Immortal"
    },
    {
      "rank": 234,
      "name": "Rookie_Pro17",
      "wr": 83,
      "match": 325,
      "badge": "Top Worker"
    },
    {
      "rank": 235,
      "name": "Kaiser_Mythic65",
      "wr": 82.6,
      "match": 327,
      "badge": "Pro Mythic"
    },
    {
      "rank": 236,
      "name": "Kaiser_Prime78",
      "wr": 82.8,
      "match": 314,
      "badge": "Pro Mythic"
    },
    {
      "rank": 237,
      "name": "Hyper_X68",
      "wr": 82.7,
      "match": 319,
      "badge": "Top Worker"
    },
    {
      "rank": 238,
      "name": "Omega_Pro47",
      "wr": 82.5,
      "match": 309,
      "badge": "Top Worker"
    },
    {
      "rank": 239,
      "name": "Blitz_Master92",
      "wr": 82.7,
      "match": 319,
      "badge": "Top Worker"
    },
    {
      "rank": 240,
      "name": "Phantom_Glory74",
      "wr": 82.5,
      "match": 320,
      "badge": "Top Worker"
    },
    {
      "rank": 241,
      "name": "Kaiser_X80",
      "wr": 82.5,
      "match": 320,
      "badge": "Top Worker"
    },
    {
      "rank": 242,
      "name": "Kaiser_Glory31",
      "wr": 82.1,
      "match": 323,
      "badge": "Pro Immortal"
    },
    {
      "rank": 243,
      "name": "Zeta_Pro56",
      "wr": 82.1,
      "match": 307,
      "badge": "Pro Glory"
    },
    {
      "rank": 244,
      "name": "Shadow_X78",
      "wr": 82.4,
      "match": 321,
      "badge": "Pro Immortal"
    },
    {
      "rank": 245,
      "name": "Spectre_God66",
      "wr": 82,
      "match": 309,
      "badge": "Top Worker"
    },
    {
      "rank": 246,
      "name": "Hyper_Prime40",
      "wr": 82.3,
      "match": 311,
      "badge": "Pro Mythic"
    },
    {
      "rank": 247,
      "name": "Hyper_Exa86",
      "wr": 82.1,
      "match": 316,
      "badge": "Pro Mythic"
    },
    {
      "rank": 248,
      "name": "Blitz_Zero24",
      "wr": 82.1,
      "match": 306,
      "badge": "Pro Mythic"
    },
    {
      "rank": 249,
      "name": "Zeta_Master98",
      "wr": 81.7,
      "match": 304,
      "badge": "Top Worker"
    },
    {
      "rank": 250,
      "name": "Nexus_Zero44",
      "wr": 81.8,
      "match": 318,
      "badge": "Pro Mythic"
    },
    {
      "rank": 251,
      "name": "Phantom_MLBB73",
      "wr": 81.8,
      "match": 306,
      "badge": "Top Worker"
    },
    {
      "rank": 252,
      "name": "Omega_Exa98",
      "wr": 81.8,
      "match": 304,
      "badge": "Pro Mythic"
    },
    {
      "rank": 253,
      "name": "Spectre_MLBB44",
      "wr": 81.8,
      "match": 311,
      "badge": "Top Worker"
    },
    {
      "rank": 254,
      "name": "Zeta_King68",
      "wr": 81.4,
      "match": 308,
      "badge": "Pro Mythic"
    },
    {
      "rank": 255,
      "name": "Kaiser_MLBB78",
      "wr": 81.5,
      "match": 301,
      "badge": "Pro Immortal"
    },
    {
      "rank": 256,
      "name": "Slayer_X28",
      "wr": 81.4,
      "match": 297,
      "badge": "Top Worker"
    },
    {
      "rank": 257,
      "name": "Nexus_Zero12",
      "wr": 81.4,
      "match": 298,
      "badge": "Pro Glory"
    },
    {
      "rank": 258,
      "name": "Shadow_Glory60",
      "wr": 81.2,
      "match": 299,
      "badge": "Pro Mythic"
    },
    {
      "rank": 259,
      "name": "Nexus_Master82",
      "wr": 80.9,
      "match": 309,
      "badge": "Pro Glory"
    },
    {
      "rank": 260,
      "name": "Hyper_Pro22",
      "wr": 81,
      "match": 310,
      "badge": "Pro Immortal"
    },
    {
      "rank": 261,
      "name": "Omega_Prime63",
      "wr": 80.8,
      "match": 308,
      "badge": "Pro Mythic"
    },
    {
      "rank": 262,
      "name": "Rookie_Pro38",
      "wr": 80.9,
      "match": 294,
      "badge": "Pro Mythic"
    },
    {
      "rank": 263,
      "name": "Phantom_Zero82",
      "wr": 80.9,
      "match": 302,
      "badge": "Pro Glory"
    },
    {
      "rank": 264,
      "name": "Omega_X59",
      "wr": 80.7,
      "match": 307,
      "badge": "Pro Mythic"
    },
    {
      "rank": 265,
      "name": "Kaiser_Zero82",
      "wr": 80.6,
      "match": 294,
      "badge": "Pro Mythic"
    },
    {
      "rank": 266,
      "name": "Alpha_Master72",
      "wr": 80.7,
      "match": 294,
      "badge": "Top Worker"
    },
    {
      "rank": 267,
      "name": "Omega_Prime65",
      "wr": 80.5,
      "match": 297,
      "badge": "Pro Immortal"
    },
    {
      "rank": 268,
      "name": "Kaiser_God61",
      "wr": 80.4,
      "match": 294,
      "badge": "Pro Mythic"
    },
    {
      "rank": 269,
      "name": "Shadow_King57",
      "wr": 80.5,
      "match": 307,
      "badge": "Pro Mythic"
    },
    {
      "rank": 270,
      "name": "Blitz_Mythic1",
      "wr": 80.2,
      "match": 295,
      "badge": "Pro Glory"
    },
    {
      "rank": 271,
      "name": "Rookie_Glory15",
      "wr": 80.3,
      "match": 290,
      "badge": "Pro Mythic"
    },
    {
      "rank": 272,
      "name": "Spectre_MLBB81",
      "wr": 80.4,
      "match": 292,
      "badge": "Pro Glory"
    },
    {
      "rank": 273,
      "name": "Zeta_God61",
      "wr": 80,
      "match": 301,
      "badge": "Pro Mythic"
    },
    {
      "rank": 274,
      "name": "Shadow_X60",
      "wr": 80.2,
      "match": 301,
      "badge": "Pro Glory"
    },
    {
      "rank": 275,
      "name": "Alpha_King87",
      "wr": 80.1,
      "match": 302,
      "badge": "Pro Immortal"
    },
    {
      "rank": 276,
      "name": "Hyper_Zero67",
      "wr": 80,
      "match": 285,
      "badge": "Pro Immortal"
    },
    {
      "rank": 277,
      "name": "Rookie_X64",
      "wr": 79.7,
      "match": 294,
      "badge": "Pro Glory"
    },
    {
      "rank": 278,
      "name": "Nexus_X56",
      "wr": 79.6,
      "match": 287,
      "badge": "Top Worker"
    },
    {
      "rank": 279,
      "name": "Viper_X57",
      "wr": 79.9,
      "match": 291,
      "badge": "Top Worker"
    },
    {
      "rank": 280,
      "name": "Apex_Mythic7",
      "wr": 79.7,
      "match": 295,
      "badge": "Pro Mythic"
    },
    {
      "rank": 281,
      "name": "Spectre_Pro50",
      "wr": 79.5,
      "match": 281,
      "badge": "Pro Glory"
    },
    {
      "rank": 282,
      "name": "Blitz_MLBB5",
      "wr": 79.5,
      "match": 294,
      "badge": "Pro Immortal"
    },
    {
      "rank": 283,
      "name": "Viper_Zero4",
      "wr": 79.3,
      "match": 283,
      "badge": "Pro Glory"
    },
    {
      "rank": 284,
      "name": "Alpha_Glory93",
      "wr": 79.4,
      "match": 288,
      "badge": "Top Worker"
    },
    {
      "rank": 285,
      "name": "Apex_Prime48",
      "wr": 79.1,
      "match": 298,
      "badge": "Pro Glory"
    },
    {
      "rank": 286,
      "name": "Slayer_Exa15",
      "wr": 79.1,
      "match": 289,
      "badge": "Pro Glory"
    },
    {
      "rank": 287,
      "name": "Spectre_King0",
      "wr": 79.3,
      "match": 297,
      "badge": "Top Worker"
    },
    {
      "rank": 288,
      "name": "Slayer_X54",
      "wr": 79.1,
      "match": 293,
      "badge": "Pro Glory"
    },
    {
      "rank": 289,
      "name": "Apex_Exa19",
      "wr": 78.9,
      "match": 295,
      "badge": "Pro Immortal"
    },
    {
      "rank": 290,
      "name": "Rookie_Glory53",
      "wr": 79,
      "match": 294,
      "badge": "Pro Immortal"
    },
    {
      "rank": 291,
      "name": "Zeta_King8",
      "wr": 78.7,
      "match": 276,
      "badge": "Pro Immortal"
    },
    {
      "rank": 292,
      "name": "Zeta_Pro51",
      "wr": 78.8,
      "match": 285,
      "badge": "Pro Immortal"
    },
    {
      "rank": 293,
      "name": "Kaiser_X37",
      "wr": 78.6,
      "match": 292,
      "badge": "Pro Mythic"
    },
    {
      "rank": 294,
      "name": "Blitz_Mythic98",
      "wr": 78.8,
      "match": 280,
      "badge": "Pro Mythic"
    },
    {
      "rank": 295,
      "name": "Kaiser_Glory66",
      "wr": 78.5,
      "match": 279,
      "badge": "Pro Immortal"
    },
    {
      "rank": 296,
      "name": "Hyper_Mythic94",
      "wr": 78.7,
      "match": 284,
      "badge": "Top Worker"
    },
    {
      "rank": 297,
      "name": "Hyper_Zero6",
      "wr": 78.7,
      "match": 290,
      "badge": "Top Worker"
    },
    {
      "rank": 298,
      "name": "Alpha_X40",
      "wr": 78.5,
      "match": 279,
      "badge": "Pro Mythic"
    },
    {
      "rank": 299,
      "name": "Shadow_God96",
      "wr": 78.3,
      "match": 275,
      "badge": "Pro Glory"
    },
    {
      "rank": 300,
      "name": "Phantom_God59",
      "wr": 78.5,
      "match": 281,
      "badge": "Top Worker"
    },
    {
      "rank": 301,
      "name": "Hyper_X17",
      "wr": 78.1,
      "match": 274,
      "badge": "Pro Mythic"
    },
    {
      "rank": 302,
      "name": "Slayer_MLBB57",
      "wr": 78.3,
      "match": 270,
      "badge": "Pro Glory"
    },
    {
      "rank": 303,
      "name": "Rookie_Master48",
      "wr": 78.1,
      "match": 280,
      "badge": "Pro Immortal"
    },
    {
      "rank": 304,
      "name": "Zeta_Mythic92",
      "wr": 78.1,
      "match": 271,
      "badge": "Pro Glory"
    },
    {
      "rank": 305,
      "name": "Omega_Exa38",
      "wr": 78.1,
      "match": 267,
      "badge": "Pro Glory"
    },
    {
      "rank": 306,
      "name": "Spectre_MLBB95",
      "wr": 78.1,
      "match": 275,
      "badge": "Pro Glory"
    },
    {
      "rank": 307,
      "name": "Spectre_Mythic90",
      "wr": 77.6,
      "match": 284,
      "badge": "Pro Mythic"
    },
    {
      "rank": 308,
      "name": "Alpha_Master48",
      "wr": 77.7,
      "match": 278,
      "badge": "Pro Mythic"
    },
    {
      "rank": 309,
      "name": "Phantom_Exa65",
      "wr": 77.8,
      "match": 273,
      "badge": "Top Worker"
    },
    {
      "rank": 310,
      "name": "Alpha_Exa26",
      "wr": 77.5,
      "match": 272,
      "badge": "Pro Glory"
    },
    {
      "rank": 311,
      "name": "Spectre_God2",
      "wr": 77.4,
      "match": 282,
      "badge": "Top Worker"
    },
    {
      "rank": 312,
      "name": "Phantom_God25",
      "wr": 77.3,
      "match": 270,
      "badge": "Pro Glory"
    },
    {
      "rank": 313,
      "name": "Apex_X83",
      "wr": 77.6,
      "match": 268,
      "badge": "Top Worker"
    },
    {
      "rank": 314,
      "name": "Spectre_Glory94",
      "wr": 77.3,
      "match": 264,
      "badge": "Pro Mythic"
    },
    {
      "rank": 315,
      "name": "Kaiser_God92",
      "wr": 77.2,
      "match": 264,
      "badge": "Pro Immortal"
    },
    {
      "rank": 316,
      "name": "Hyper_Pro9",
      "wr": 77.4,
      "match": 273,
      "badge": "Pro Immortal"
    },
    {
      "rank": 317,
      "name": "Shadow_God80",
      "wr": 76.9,
      "match": 273,
      "badge": "Pro Immortal"
    },
    {
      "rank": 318,
      "name": "Zeta_X58",
      "wr": 76.9,
      "match": 271,
      "badge": "Top Worker"
    },
    {
      "rank": 319,
      "name": "Slayer_Zero2",
      "wr": 76.7,
      "match": 269,
      "badge": "Pro Immortal"
    },
    {
      "rank": 320,
      "name": "Rookie_X92",
      "wr": 76.7,
      "match": 277,
      "badge": "Pro Immortal"
    },
    {
      "rank": 321,
      "name": "Hyper_Glory55",
      "wr": 76.9,
      "match": 275,
      "badge": "Pro Immortal"
    },
    {
      "rank": 322,
      "name": "Viper_X19",
      "wr": 76.6,
      "match": 269,
      "badge": "Pro Mythic"
    },
    {
      "rank": 323,
      "name": "Omega_Exa34",
      "wr": 76.8,
      "match": 257,
      "badge": "Top Worker"
    },
    {
      "rank": 324,
      "name": "Apex_Mythic31",
      "wr": 76.8,
      "match": 260,
      "badge": "Pro Immortal"
    },
    {
      "rank": 325,
      "name": "Slayer_Glory97",
      "wr": 76.3,
      "match": 263,
      "badge": "Top Worker"
    },
    {
      "rank": 326,
      "name": "Hyper_Zero7",
      "wr": 76.5,
      "match": 268,
      "badge": "Pro Immortal"
    },
    {
      "rank": 327,
      "name": "Apex_Prime82",
      "wr": 76.5,
      "match": 265,
      "badge": "Pro Immortal"
    },
    {
      "rank": 328,
      "name": "Hyper_Pro29",
      "wr": 76.1,
      "match": 270,
      "badge": "Top Worker"
    },
    {
      "rank": 329,
      "name": "Phantom_Pro9",
      "wr": 76.3,
      "match": 258,
      "badge": "Pro Immortal"
    },
    {
      "rank": 330,
      "name": "Kaiser_Exa2",
      "wr": 76.4,
      "match": 263,
      "badge": "Top Worker"
    },
    {
      "rank": 331,
      "name": "Viper_Master20",
      "wr": 76.1,
      "match": 262,
      "badge": "Top Worker"
    },
    {
      "rank": 332,
      "name": "Slayer_X42",
      "wr": 76,
      "match": 265,
      "badge": "Pro Immortal"
    },
    {
      "rank": 333,
      "name": "Hyper_Exa6",
      "wr": 75.7,
      "match": 254,
      "badge": "Pro Immortal"
    },
    {
      "rank": 334,
      "name": "Nexus_Mythic98",
      "wr": 75.9,
      "match": 261,
      "badge": "Pro Mythic"
    },
    {
      "rank": 335,
      "name": "Rookie_Glory34",
      "wr": 75.9,
      "match": 258,
      "badge": "Pro Glory"
    },
    {
      "rank": 336,
      "name": "Nexus_X48",
      "wr": 75.7,
      "match": 261,
      "badge": "Top Worker"
    },
    {
      "rank": 337,
      "name": "Viper_Mythic37",
      "wr": 75.8,
      "match": 262,
      "badge": "Pro Immortal"
    },
    {
      "rank": 338,
      "name": "Phantom_God48",
      "wr": 75.7,
      "match": 259,
      "badge": "Top Worker"
    },
    {
      "rank": 339,
      "name": "Nexus_Exa13",
      "wr": 75.3,
      "match": 265,
      "badge": "Top Worker"
    },
    {
      "rank": 340,
      "name": "Nexus_Master13",
      "wr": 75.3,
      "match": 249,
      "badge": "Top Worker"
    },
    {
      "rank": 341,
      "name": "Hyper_X65",
      "wr": 75.3,
      "match": 245,
      "badge": "Pro Mythic"
    },
    {
      "rank": 342,
      "name": "Hyper_MLBB76",
      "wr": 75.4,
      "match": 251,
      "badge": "Top Worker"
    },
    {
      "rank": 343,
      "name": "Rookie_Master52",
      "wr": 75.2,
      "match": 245,
      "badge": "Pro Glory"
    },
    {
      "rank": 344,
      "name": "Blitz_X21",
      "wr": 75.3,
      "match": 246,
      "badge": "Pro Mythic"
    },
    {
      "rank": 345,
      "name": "Phantom_Master63",
      "wr": 74.9,
      "match": 246,
      "badge": "Pro Mythic"
    },
    {
      "rank": 346,
      "name": "Shadow_Master61",
      "wr": 75.2,
      "match": 249,
      "badge": "Pro Glory"
    },
    {
      "rank": 347,
      "name": "Spectre_Glory63",
      "wr": 75,
      "match": 245,
      "badge": "Pro Immortal"
    },
    {
      "rank": 348,
      "name": "Kaiser_Master0",
      "wr": 75.1,
      "match": 247,
      "badge": "Top Worker"
    },
    {
      "rank": 349,
      "name": "Alpha_Exa56",
      "wr": 74.7,
      "match": 256,
      "badge": "Pro Glory"
    },
    {
      "rank": 350,
      "name": "Phantom_Exa77",
      "wr": 75,
      "match": 244,
      "badge": "Pro Mythic"
    },
    {
      "rank": 351,
      "name": "Kaiser_Prime40",
      "wr": 74.6,
      "match": 253,
      "badge": "Top Worker"
    },
    {
      "rank": 352,
      "name": "Blitz_King41",
      "wr": 74.5,
      "match": 255,
      "badge": "Top Worker"
    },
    {
      "rank": 353,
      "name": "Nexus_MLBB72",
      "wr": 74.4,
      "match": 258,
      "badge": "Pro Glory"
    },
    {
      "rank": 354,
      "name": "Slayer_X3",
      "wr": 74.7,
      "match": 246,
      "badge": "Pro Glory"
    },
    {
      "rank": 355,
      "name": "Apex_Master88",
      "wr": 74.2,
      "match": 253,
      "badge": "Top Worker"
    },
    {
      "rank": 356,
      "name": "Slayer_Zero17",
      "wr": 74.4,
      "match": 241,
      "badge": "Pro Glory"
    },
    {
      "rank": 357,
      "name": "Spectre_Prime48",
      "wr": 74,
      "match": 255,
      "badge": "Top Worker"
    },
    {
      "rank": 358,
      "name": "Blitz_Prime68",
      "wr": 74.2,
      "match": 253,
      "badge": "Top Worker"
    },
    {
      "rank": 359,
      "name": "Hyper_Pro46",
      "wr": 74.2,
      "match": 250,
      "badge": "Pro Immortal"
    },
    {
      "rank": 360,
      "name": "Viper_King84",
      "wr": 74.1,
      "match": 237,
      "badge": "Pro Immortal"
    },
    {
      "rank": 361,
      "name": "Blitz_Glory86",
      "wr": 74.1,
      "match": 252,
      "badge": "Pro Mythic"
    },
    {
      "rank": 362,
      "name": "Alpha_Prime13",
      "wr": 73.7,
      "match": 237,
      "badge": "Pro Glory"
    },
    {
      "rank": 363,
      "name": "Apex_Exa50",
      "wr": 73.8,
      "match": 245,
      "badge": "Pro Glory"
    },
    {
      "rank": 364,
      "name": "Nexus_Pro61",
      "wr": 73.6,
      "match": 239,
      "badge": "Pro Immortal"
    },
    {
      "rank": 365,
      "name": "Viper_God44",
      "wr": 73.6,
      "match": 240,
      "badge": "Pro Glory"
    },
    {
      "rank": 366,
      "name": "Hyper_Zero44",
      "wr": 73.6,
      "match": 239,
      "badge": "Top Worker"
    },
    {
      "rank": 367,
      "name": "Nexus_MLBB38",
      "wr": 73.3,
      "match": 244,
      "badge": "Pro Immortal"
    },
    {
      "rank": 368,
      "name": "Omega_Exa82",
      "wr": 73.3,
      "match": 245,
      "badge": "Pro Glory"
    },
    {
      "rank": 369,
      "name": "Hyper_God70",
      "wr": 73.3,
      "match": 239,
      "badge": "Top Worker"
    },
    {
      "rank": 370,
      "name": "Zeta_Prime80",
      "wr": 73.2,
      "match": 240,
      "badge": "Top Worker"
    },
    {
      "rank": 371,
      "name": "Shadow_Pro94",
      "wr": 73.3,
      "match": 231,
      "badge": "Top Worker"
    },
    {
      "rank": 372,
      "name": "Shadow_Pro90",
      "wr": 73.1,
      "match": 232,
      "badge": "Pro Immortal"
    },
    {
      "rank": 373,
      "name": "Blitz_MLBB68",
      "wr": 73,
      "match": 232,
      "badge": "Top Worker"
    },
    {
      "rank": 374,
      "name": "Viper_Master85",
      "wr": 73.3,
      "match": 236,
      "badge": "Pro Mythic"
    },
    {
      "rank": 375,
      "name": "Blitz_Prime78",
      "wr": 72.9,
      "match": 227,
      "badge": "Pro Mythic"
    },
    {
      "rank": 376,
      "name": "Omega_Zero79",
      "wr": 72.8,
      "match": 237,
      "badge": "Pro Mythic"
    },
    {
      "rank": 377,
      "name": "Blitz_Mythic10",
      "wr": 72.9,
      "match": 230,
      "badge": "Pro Glory"
    },
    {
      "rank": 378,
      "name": "Phantom_MLBB23",
      "wr": 72.7,
      "match": 226,
      "badge": "Top Worker"
    },
    {
      "rank": 379,
      "name": "Shadow_Mythic17",
      "wr": 72.8,
      "match": 231,
      "badge": "Top Worker"
    },
    {
      "rank": 380,
      "name": "Slayer_X88",
      "wr": 72.9,
      "match": 240,
      "badge": "Pro Glory"
    },
    {
      "rank": 381,
      "name": "Hyper_God62",
      "wr": 72.5,
      "match": 225,
      "badge": "Top Worker"
    },
    {
      "rank": 382,
      "name": "Blitz_Pro45",
      "wr": 72.7,
      "match": 230,
      "badge": "Pro Glory"
    },
    {
      "rank": 383,
      "name": "Omega_Prime71",
      "wr": 72.4,
      "match": 230,
      "badge": "Top Worker"
    },
    {
      "rank": 384,
      "name": "Shadow_Zero62",
      "wr": 72.2,
      "match": 230,
      "badge": "Pro Glory"
    },
    {
      "rank": 385,
      "name": "Phantom_Pro35",
      "wr": 72.2,
      "match": 224,
      "badge": "Top Worker"
    },
    {
      "rank": 386,
      "name": "Blitz_Zero70",
      "wr": 72.2,
      "match": 229,
      "badge": "Pro Mythic"
    },
    {
      "rank": 387,
      "name": "Alpha_X46",
      "wr": 72.2,
      "match": 232,
      "badge": "Top Worker"
    },
    {
      "rank": 388,
      "name": "Hyper_King54",
      "wr": 71.9,
      "match": 233,
      "badge": "Pro Glory"
    },
    {
      "rank": 389,
      "name": "Phantom_Pro57",
      "wr": 71.9,
      "match": 233,
      "badge": "Pro Immortal"
    },
    {
      "rank": 390,
      "name": "Apex_MLBB30",
      "wr": 71.8,
      "match": 230,
      "badge": "Pro Mythic"
    },
    {
      "rank": 391,
      "name": "Omega_Mythic80",
      "wr": 71.8,
      "match": 227,
      "badge": "Pro Glory"
    },
    {
      "rank": 392,
      "name": "Omega_King7",
      "wr": 71.8,
      "match": 225,
      "badge": "Pro Glory"
    },
    {
      "rank": 393,
      "name": "Nexus_Master37",
      "wr": 71.8,
      "match": 233,
      "badge": "Pro Immortal"
    },
    {
      "rank": 394,
      "name": "Kaiser_Prime7",
      "wr": 71.9,
      "match": 230,
      "badge": "Pro Glory"
    },
    {
      "rank": 395,
      "name": "Spectre_God31",
      "wr": 71.4,
      "match": 219,
      "badge": "Pro Glory"
    },
    {
      "rank": 396,
      "name": "Alpha_Glory50",
      "wr": 71.5,
      "match": 223,
      "badge": "Pro Mythic"
    },
    {
      "rank": 397,
      "name": "Slayer_Prime48",
      "wr": 71.4,
      "match": 224,
      "badge": "Pro Immortal"
    },
    {
      "rank": 398,
      "name": "Shadow_X95",
      "wr": 71.3,
      "match": 229,
      "badge": "Pro Mythic"
    },
    {
      "rank": 399,
      "name": "Apex_Zero41",
      "wr": 71.4,
      "match": 227,
      "badge": "Pro Immortal"
    },
    {
      "rank": 400,
      "name": "Spectre_Zero81",
      "wr": 71.3,
      "match": 217,
      "badge": "Pro Immortal"
    },
    {
      "rank": 401,
      "name": "Alpha_X50",
      "wr": 71,
      "match": 217,
      "badge": "Pro Glory"
    },
    {
      "rank": 402,
      "name": "Apex_Master41",
      "wr": 71.3,
      "match": 215,
      "badge": "Pro Glory"
    },
    {
      "rank": 403,
      "name": "Blitz_Zero43",
      "wr": 71.2,
      "match": 223,
      "badge": "Pro Immortal"
    },
    {
      "rank": 404,
      "name": "Viper_Glory58",
      "wr": 70.7,
      "match": 226,
      "badge": "Pro Glory"
    },
    {
      "rank": 405,
      "name": "Apex_Zero0",
      "wr": 71.1,
      "match": 215,
      "badge": "Pro Glory"
    },
    {
      "rank": 406,
      "name": "Slayer_Master20",
      "wr": 71,
      "match": 223,
      "badge": "Pro Immortal"
    },
    {
      "rank": 407,
      "name": "Slayer_Exa32",
      "wr": 70.6,
      "match": 219,
      "badge": "Pro Glory"
    },
    {
      "rank": 408,
      "name": "Rookie_Prime80",
      "wr": 70.6,
      "match": 219,
      "badge": "Pro Glory"
    },
    {
      "rank": 409,
      "name": "Shadow_Glory11",
      "wr": 70.7,
      "match": 204,
      "badge": "Top Worker"
    },
    {
      "rank": 410,
      "name": "Viper_God75",
      "wr": 70.4,
      "match": 217,
      "badge": "Pro Immortal"
    },
    {
      "rank": 411,
      "name": "Rookie_Exa15",
      "wr": 70.7,
      "match": 211,
      "badge": "Pro Glory"
    },
    {
      "rank": 412,
      "name": "Apex_MLBB29",
      "wr": 70.4,
      "match": 217,
      "badge": "Pro Immortal"
    },
    {
      "rank": 413,
      "name": "Viper_Exa47",
      "wr": 70.5,
      "match": 204,
      "badge": "Pro Glory"
    },
    {
      "rank": 414,
      "name": "Slayer_Glory18",
      "wr": 70.1,
      "match": 212,
      "badge": "Pro Glory"
    },
    {
      "rank": 415,
      "name": "Apex_Exa92",
      "wr": 70.1,
      "match": 215,
      "badge": "Top Worker"
    },
    {
      "rank": 416,
      "name": "Blitz_Glory56",
      "wr": 70.3,
      "match": 202,
      "badge": "Pro Immortal"
    },
    {
      "rank": 417,
      "name": "Kaiser_MLBB75",
      "wr": 70.2,
      "match": 206,
      "badge": "Top Worker"
    },
    {
      "rank": 418,
      "name": "Nexus_God31",
      "wr": 69.9,
      "match": 200,
      "badge": "Pro Mythic"
    },
    {
      "rank": 419,
      "name": "Alpha_Pro84",
      "wr": 70.1,
      "match": 202,
      "badge": "Pro Glory"
    },
    {
      "rank": 420,
      "name": "Spectre_Prime37",
      "wr": 69.9,
      "match": 213,
      "badge": "Pro Glory"
    },
    {
      "rank": 421,
      "name": "Apex_Prime14",
      "wr": 69.7,
      "match": 210,
      "badge": "Pro Immortal"
    },
    {
      "rank": 422,
      "name": "Hyper_Pro46",
      "wr": 69.9,
      "match": 199,
      "badge": "Top Worker"
    },
    {
      "rank": 423,
      "name": "Nexus_X87",
      "wr": 69.5,
      "match": 205,
      "badge": "Pro Immortal"
    },
    {
      "rank": 424,
      "name": "Rookie_Mythic8",
      "wr": 69.3,
      "match": 199,
      "badge": "Pro Immortal"
    },
    {
      "rank": 425,
      "name": "Alpha_Prime64",
      "wr": 69.4,
      "match": 209,
      "badge": "Top Worker"
    },
    {
      "rank": 426,
      "name": "Shadow_Prime10",
      "wr": 69.5,
      "match": 205,
      "badge": "Pro Glory"
    },
    {
      "rank": 427,
      "name": "Phantom_MLBB39",
      "wr": 69.1,
      "match": 212,
      "badge": "Pro Glory"
    },
    {
      "rank": 428,
      "name": "Hyper_Exa50",
      "wr": 69.3,
      "match": 208,
      "badge": "Pro Immortal"
    },
    {
      "rank": 429,
      "name": "Phantom_Prime93",
      "wr": 69.4,
      "match": 197,
      "badge": "Pro Glory"
    },
    {
      "rank": 430,
      "name": "Viper_Prime14",
      "wr": 69.1,
      "match": 204,
      "badge": "Pro Mythic"
    },
    {
      "rank": 431,
      "name": "Slayer_Glory94",
      "wr": 68.9,
      "match": 191,
      "badge": "Pro Glory"
    },
    {
      "rank": 432,
      "name": "Spectre_Pro20",
      "wr": 69,
      "match": 197,
      "badge": "Pro Mythic"
    },
    {
      "rank": 433,
      "name": "Kaiser_Exa16",
      "wr": 69.1,
      "match": 207,
      "badge": "Pro Immortal"
    },
    {
      "rank": 434,
      "name": "Alpha_Pro42",
      "wr": 69,
      "match": 195,
      "badge": "Pro Immortal"
    },
    {
      "rank": 435,
      "name": "Phantom_Mythic80",
      "wr": 68.6,
      "match": 198,
      "badge": "Pro Mythic"
    },
    {
      "rank": 436,
      "name": "Rookie_Zero72",
      "wr": 68.6,
      "match": 191,
      "badge": "Pro Immortal"
    },
    {
      "rank": 437,
      "name": "Blitz_Glory92",
      "wr": 68.5,
      "match": 202,
      "badge": "Pro Immortal"
    },
    {
      "rank": 438,
      "name": "Rookie_Pro31",
      "wr": 68.4,
      "match": 194,
      "badge": "Pro Glory"
    },
    {
      "rank": 439,
      "name": "Kaiser_Pro70",
      "wr": 68.7,
      "match": 200,
      "badge": "Top Worker"
    },
    {
      "rank": 440,
      "name": "Zeta_Exa31",
      "wr": 68.4,
      "match": 200,
      "badge": "Pro Mythic"
    },
    {
      "rank": 441,
      "name": "Omega_MLBB73",
      "wr": 68.3,
      "match": 195,
      "badge": "Pro Immortal"
    },
    {
      "rank": 442,
      "name": "Kaiser_King66",
      "wr": 68.6,
      "match": 203,
      "badge": "Pro Immortal"
    },
    {
      "rank": 443,
      "name": "Apex_Master39",
      "wr": 68.2,
      "match": 195,
      "badge": "Pro Immortal"
    },
    {
      "rank": 444,
      "name": "Nexus_King37",
      "wr": 68.2,
      "match": 189,
      "badge": "Pro Glory"
    },
    {
      "rank": 445,
      "name": "Apex_Exa75",
      "wr": 68.3,
      "match": 202,
      "badge": "Pro Glory"
    },
    {
      "rank": 446,
      "name": "Spectre_X97",
      "wr": 68.2,
      "match": 185,
      "badge": "Top Worker"
    },
    {
      "rank": 447,
      "name": "Rookie_King69",
      "wr": 67.9,
      "match": 198,
      "badge": "Pro Immortal"
    },
    {
      "rank": 448,
      "name": "Nexus_Pro97",
      "wr": 68,
      "match": 198,
      "badge": "Pro Mythic"
    },
    {
      "rank": 449,
      "name": "Viper_King67",
      "wr": 68.1,
      "match": 188,
      "badge": "Pro Immortal"
    },
    {
      "rank": 450,
      "name": "Kaiser_Master11",
      "wr": 67.5,
      "match": 184,
      "badge": "Top Worker"
    },
    {
      "rank": 451,
      "name": "Spectre_Exa58",
      "wr": 67.9,
      "match": 181,
      "badge": "Pro Immortal"
    },
    {
      "rank": 452,
      "name": "Hyper_God81",
      "wr": 67.8,
      "match": 180,
      "badge": "Pro Immortal"
    },
    {
      "rank": 453,
      "name": "Shadow_Glory16",
      "wr": 67.4,
      "match": 183,
      "badge": "Pro Mythic"
    },
    {
      "rank": 454,
      "name": "Alpha_Prime89",
      "wr": 67.6,
      "match": 184,
      "badge": "Top Worker"
    },
    {
      "rank": 455,
      "name": "Phantom_King9",
      "wr": 67.6,
      "match": 179,
      "badge": "Pro Immortal"
    },
    {
      "rank": 456,
      "name": "Kaiser_MLBB21",
      "wr": 67.3,
      "match": 182,
      "badge": "Pro Immortal"
    },
    {
      "rank": 457,
      "name": "Hyper_Exa98",
      "wr": 67.1,
      "match": 181,
      "badge": "Pro Mythic"
    },
    {
      "rank": 458,
      "name": "Omega_MLBB11",
      "wr": 67,
      "match": 188,
      "badge": "Pro Immortal"
    },
    {
      "rank": 459,
      "name": "Zeta_Exa18",
      "wr": 66.9,
      "match": 179,
      "badge": "Pro Mythic"
    },
    {
      "rank": 460,
      "name": "Shadow_X6",
      "wr": 67.1,
      "match": 179,
      "badge": "Pro Glory"
    },
    {
      "rank": 461,
      "name": "Rookie_Prime57",
      "wr": 67,
      "match": 184,
      "badge": "Pro Immortal"
    },
    {
      "rank": 462,
      "name": "Apex_MLBB17",
      "wr": 66.7,
      "match": 174,
      "badge": "Pro Glory"
    },
    {
      "rank": 463,
      "name": "Kaiser_King51",
      "wr": 66.8,
      "match": 184,
      "badge": "Pro Immortal"
    },
    {
      "rank": 464,
      "name": "Blitz_Mythic33",
      "wr": 67,
      "match": 173,
      "badge": "Pro Immortal"
    },
    {
      "rank": 465,
      "name": "Zeta_Glory56",
      "wr": 66.9,
      "match": 172,
      "badge": "Pro Mythic"
    },
    {
      "rank": 466,
      "name": "Viper_Pro59",
      "wr": 66.4,
      "match": 188,
      "badge": "Top Worker"
    },
    {
      "rank": 467,
      "name": "Omega_Prime63",
      "wr": 66.3,
      "match": 183,
      "badge": "Pro Glory"
    },
    {
      "rank": 468,
      "name": "Nexus_King23",
      "wr": 66.4,
      "match": 178,
      "badge": "Pro Glory"
    },
    {
      "rank": 469,
      "name": "Rookie_Mythic79",
      "wr": 66.5,
      "match": 181,
      "badge": "Top Worker"
    },
    {
      "rank": 470,
      "name": "Shadow_X61",
      "wr": 66.1,
      "match": 173,
      "badge": "Pro Glory"
    },
    {
      "rank": 471,
      "name": "Shadow_King82",
      "wr": 66.5,
      "match": 177,
      "badge": "Pro Immortal"
    },
    {
      "rank": 472,
      "name": "Shadow_Exa61",
      "wr": 66.2,
      "match": 176,
      "badge": "Pro Mythic"
    },
    {
      "rank": 473,
      "name": "Shadow_Master23",
      "wr": 65.9,
      "match": 178,
      "badge": "Pro Immortal"
    },
    {
      "rank": 474,
      "name": "Alpha_Master7",
      "wr": 66.2,
      "match": 175,
      "badge": "Pro Mythic"
    },
    {
      "rank": 475,
      "name": "Alpha_Mythic29",
      "wr": 66.2,
      "match": 167,
      "badge": "Pro Glory"
    },
    {
      "rank": 476,
      "name": "Phantom_X94",
      "wr": 65.7,
      "match": 184,
      "badge": "Pro Glory"
    },
    {
      "rank": 477,
      "name": "Blitz_Prime45",
      "wr": 66.1,
      "match": 183,
      "badge": "Pro Glory"
    },
    {
      "rank": 478,
      "name": "Kaiser_King75",
      "wr": 65.7,
      "match": 177,
      "badge": "Pro Mythic"
    },
    {
      "rank": 479,
      "name": "Blitz_Pro90",
      "wr": 65.8,
      "match": 181,
      "badge": "Pro Glory"
    },
    {
      "rank": 480,
      "name": "Blitz_King63",
      "wr": 65.7,
      "match": 165,
      "badge": "Pro Immortal"
    },
    {
      "rank": 481,
      "name": "Viper_Pro29",
      "wr": 65.6,
      "match": 161,
      "badge": "Top Worker"
    },
    {
      "rank": 482,
      "name": "Rookie_Exa78",
      "wr": 65.4,
      "match": 163,
      "badge": "Pro Glory"
    },
    {
      "rank": 483,
      "name": "Alpha_Exa7",
      "wr": 65.2,
      "match": 171,
      "badge": "Pro Glory"
    },
    {
      "rank": 484,
      "name": "Alpha_MLBB67",
      "wr": 65.6,
      "match": 178,
      "badge": "Pro Mythic"
    },
    {
      "rank": 485,
      "name": "Spectre_Glory50",
      "wr": 65.3,
      "match": 165,
      "badge": "Pro Mythic"
    },
    {
      "rank": 486,
      "name": "Kaiser_God93",
      "wr": 65.5,
      "match": 174,
      "badge": "Top Worker"
    },
    {
      "rank": 487,
      "name": "Slayer_Exa22",
      "wr": 65.3,
      "match": 169,
      "badge": "Pro Mythic"
    },
    {
      "rank": 488,
      "name": "Zeta_Glory75",
      "wr": 65.2,
      "match": 164,
      "badge": "Pro Mythic"
    },
    {
      "rank": 489,
      "name": "Kaiser_God93",
      "wr": 65,
      "match": 170,
      "badge": "Top Worker"
    },
    {
      "rank": 490,
      "name": "Omega_Mythic4",
      "wr": 65,
      "match": 162,
      "badge": "Pro Glory"
    },
    {
      "rank": 491,
      "name": "Slayer_Mythic13",
      "wr": 65.1,
      "match": 158,
      "badge": "Pro Immortal"
    },
    {
      "rank": 492,
      "name": "Zeta_Exa40",
      "wr": 65,
      "match": 172,
      "badge": "Pro Immortal"
    },
    {
      "rank": 493,
      "name": "Omega_Glory81",
      "wr": 65,
      "match": 160,
      "badge": "Pro Immortal"
    },
    {
      "rank": 494,
      "name": "Phantom_King31",
      "wr": 65,
      "match": 160,
      "badge": "Pro Immortal"
    },
    {
      "rank": 495,
      "name": "Spectre_Pro6",
      "wr": 65,
      "match": 167,
      "badge": "Pro Glory"
    },
    {
      "rank": 496,
      "name": "Shadow_Zero48",
      "wr": 65,
      "match": 159,
      "badge": "Top Worker"
    },
    {
      "rank": 497,
      "name": "Alpha_Mythic83",
      "wr": 65,
      "match": 156,
      "badge": "Top Worker"
    },
    {
      "rank": 498,
      "name": "Viper_Pro37",
      "wr": 65,
      "match": 156,
      "badge": "Pro Immortal"
    },
    {
      "rank": 499,
      "name": "Viper_Exa21",
      "wr": 65,
      "match": 153,
      "badge": "Pro Immortal"
    },
    {
      "rank": 500,
      "name": "Hyper_MLBB43",
      "wr": 65,
      "match": 162,
      "badge": "Top Worker"
    }
  ],
  "orders": [
    {
      "id": "RK-1001",
      "customer": "Citra M.",
      "phone": "085126018159",
      "service": "Joki Rank Epic to Legend",
      "worker": "Rookie_Alpha",
      "status": "On Process",
      "progress": "2/6 Jam",
      "date": "3 Sep 2026"
    },
    {
      "id": "RK-1002",
      "customer": "Eka K.",
      "phone": "081386091390",
      "service": "Joki Gendong VIP 5 Win",
      "worker": "Rookie_Omega",
      "status": "On Process",
      "progress": "4/5 Match",
      "date": "30 Aug 2026"
    },
    {
      "id": "RK-1003",
      "customer": "Taufik S.",
      "phone": "085228194821",
      "service": "Joki Gendong VIP 5 Win",
      "worker": "Rookie_Omega",
      "status": "Done",
      "progress": "5/5 Win",
      "date": "13 Sep 2026"
    },
    {
      "id": "RK-1004",
      "customer": "Citra K.",
      "phone": "081293786579",
      "service": "Push 100 Bintang Mythical Immortal",
      "worker": "Rookie_Blitz",
      "status": "On Process",
      "progress": "4/6 Bintang",
      "date": "9 Sep 2026"
    },
    {
      "id": "RK-1005",
      "customer": "Nanda P.",
      "phone": "085875749118",
      "service": "Joki WR Target 70%",
      "worker": "Rookie_Zeta",
      "status": "Done",
      "progress": "10/10 Bintang",
      "date": "1 Sep 2026"
    },
    {
      "id": "RK-1006",
      "customer": "Rian S.",
      "phone": "081389555979",
      "service": "Paket Kilat 5 Bintang",
      "worker": "Rookie_Blitz",
      "status": "Pending",
      "progress": "Menunggu Worker",
      "date": "8 Sep 2026"
    },
    {
      "id": "RK-1007",
      "customer": "Gilang K.",
      "phone": "081249746507",
      "service": "Joki Placement 10 Match",
      "worker": "Rookie_Zeta",
      "status": "Done",
      "progress": "Target Tercapai",
      "date": "15 Sep 2026"
    },
    {
      "id": "RK-1008",
      "customer": "Indra W.",
      "phone": "082136671276",
      "service": "Legend to Mythic Placement",
      "worker": "Rookie_Apex",
      "status": "Done",
      "progress": "Target Tercapai",
      "date": "30 Aug 2026"
    },
    {
      "id": "RK-1009",
      "customer": "Joko P.",
      "phone": "085163212233",
      "service": "Joki Rank Epic to Legend",
      "worker": "Rookie_Blitz",
      "status": "Done",
      "progress": "10/10 Bintang",
      "date": "8 Sep 2026"
    },
    {
      "id": "RK-1010",
      "customer": "Taufik W.",
      "phone": "082168599528",
      "service": "Joki Gendong VIP 5 Win",
      "worker": "Rookie_Nexus",
      "status": "Done",
      "progress": "Selesai 100%",
      "date": "2 Sep 2026"
    },
    {
      "id": "RK-1011",
      "customer": "Andi R.",
      "phone": "085266176031",
      "service": "Mythic Gradasi 25 Bintang",
      "worker": "Rookie_Blitz",
      "status": "On Process",
      "progress": "6/7 Bintang",
      "date": "13 Sep 2026"
    },
    {
      "id": "RK-1012",
      "customer": "Dewi S.",
      "phone": "085815901396",
      "service": "Push Mythic 10 Bintang",
      "worker": "Rookie_Nexus",
      "status": "On Process",
      "progress": "6/9 Bintang",
      "date": "1 Sep 2026"
    },
    {
      "id": "RK-1013",
      "customer": "Sinta A.",
      "phone": "085777741215",
      "service": "Joki Turnamen MRO Piala Biru",
      "worker": "Rookie_Apex",
      "status": "On Process",
      "progress": "3/4 Jam",
      "date": "10 Sep 2026"
    },
    {
      "id": "RK-1014",
      "customer": "Hana M.",
      "phone": "082180841485",
      "service": "Push 100 Bintang Mythical Immortal",
      "worker": "Rookie_Zeta",
      "status": "On Process",
      "progress": "4/7 Bintang",
      "date": "27 Aug 2026"
    },
    {
      "id": "RK-1015",
      "customer": "Lina A.",
      "phone": "082263387500",
      "service": "Paket Kilat 5 Bintang",
      "worker": "Rookie_Apex",
      "status": "On Process",
      "progress": "4/7 Bintang",
      "date": "2 Sep 2026"
    },
    {
      "id": "RK-1016",
      "customer": "Lina S.",
      "phone": "081331373537",
      "service": "Joki Gendong VIP 5 Win",
      "worker": "Rookie_Omega",
      "status": "Done",
      "progress": "Target Tercapai",
      "date": "27 Aug 2026"
    },
    {
      "id": "RK-1017",
      "customer": "Fajar R.",
      "phone": "081363726516",
      "service": "Joki WR Target 85% Fanny",
      "worker": "Rookie_Hyper",
      "status": "Done",
      "progress": "Selesai 100%",
      "date": "11 Sep 2026"
    },
    {
      "id": "RK-1018",
      "customer": "Dewi R.",
      "phone": "081229729975",
      "service": "Push Mythic 10 Bintang",
      "worker": "Rookie_Alpha",
      "status": "Done",
      "progress": "Selesai 100%",
      "date": "16 Sep 2026"
    },
    {
      "id": "RK-1019",
      "customer": "Lina H.",
      "phone": "085233043483",
      "service": "Paket Kilat 5 Bintang",
      "worker": "Rookie_Omega",
      "status": "On Process",
      "progress": "7/9 Bintang",
      "date": "15 Sep 2026"
    },
    {
      "id": "RK-1020",
      "customer": "Fajar R.",
      "phone": "085868282880",
      "service": "Joki Solo Rank Aman Epic",
      "worker": "Rookie_Blitz",
      "status": "Done",
      "progress": "Selesai 100%",
      "date": "12 Sep 2026"
    },
    {
      "id": "RK-1021",
      "customer": "Gilang K.",
      "phone": "085791805888",
      "service": "Joki WR Target 85% Fanny",
      "worker": "Rookie_Kaiser",
      "status": "Done",
      "progress": "Selesai 100%",
      "date": "9 Sep 2026"
    },
    {
      "id": "RK-1022",
      "customer": "Putri H.",
      "phone": "081218780175",
      "service": "Joki Gendong VIP 5 Win",
      "worker": "Rookie_Alpha",
      "status": "Done",
      "progress": "10/10 Bintang",
      "date": "8 Sep 2026"
    },
    {
      "id": "RK-1023",
      "customer": "Citra M.",
      "phone": "085838483726",
      "service": "Joki Rank Grandmaster to Epic",
      "worker": "Rookie_Hyper",
      "status": "On Process",
      "progress": "2/4 Jam",
      "date": "3 Sep 2026"
    },
    {
      "id": "RK-1024",
      "customer": "Fajar W.",
      "phone": "083112524273",
      "service": "Joki Turnamen MRO Piala Biru",
      "worker": "Rookie_Kaiser",
      "status": "On Process",
      "progress": "8/10 Jam",
      "date": "9 Sep 2026"
    },
    {
      "id": "RK-1025",
      "customer": "Mega A.",
      "phone": "085865635515",
      "service": "Joki Rank Epic to Legend",
      "worker": "Rookie_Shadow",
      "status": "Done",
      "progress": "Target Tercapai",
      "date": "16 Sep 2026"
    },
    {
      "id": "RK-1026",
      "customer": "Eka W.",
      "phone": "085894811311",
      "service": "Push Mythical Glory 50 Bintang",
      "worker": "Rookie_Apex",
      "status": "Pending",
      "progress": "Menunggu Worker",
      "date": "8 Sep 2026"
    },
    {
      "id": "RK-1027",
      "customer": "Citra K.",
      "phone": "083162889751",
      "service": "Push Mythical Glory 50 Bintang",
      "worker": "Rookie_Viper",
      "status": "Done",
      "progress": "10/10 Bintang",
      "date": "3 Sep 2026"
    },
    {
      "id": "RK-1028",
      "customer": "Eka P.",
      "phone": "081214193141",
      "service": "Joki WR Target 85% Fanny",
      "worker": "Rookie_Viper",
      "status": "On Process",
      "progress": "7/10 Jam",
      "date": "28 Aug 2026"
    },
    {
      "id": "RK-1029",
      "customer": "Putri R.",
      "phone": "085831240234",
      "service": "Mabar VIP Squad 2 Jam",
      "worker": "Rookie_Apex",
      "status": "Done",
      "progress": "10/10 Bintang",
      "date": "7 Sep 2026"
    },
    {
      "id": "RK-1030",
      "customer": "Nanda H.",
      "phone": "083150400088",
      "service": "Mythic Gradasi 25 Bintang",
      "worker": "Rookie_Alpha",
      "status": "On Process",
      "progress": "8/9 Bintang",
      "date": "27 Aug 2026"
    },
    {
      "id": "RK-1031",
      "customer": "Citra K.",
      "phone": "085868433532",
      "service": "Joki WR Target 70%",
      "worker": "Rookie_Shadow",
      "status": "Dibatalkan",
      "progress": "Dibatalkan oleh Pelanggan",
      "date": "16 Sep 2026"
    },
    {
      "id": "RK-1032",
      "customer": "Indra H.",
      "phone": "085220168493",
      "service": "Joki Turnamen MRO Piala Biru",
      "worker": "Rookie_Apex",
      "status": "Pending",
      "progress": "Menunggu Worker",
      "date": "11 Sep 2026"
    },
    {
      "id": "RK-1033",
      "customer": "Rian K.",
      "phone": "081245585304",
      "service": "Mythic Gradasi 25 Bintang",
      "worker": "Rookie_Shadow",
      "status": "On Process",
      "progress": "6/10 Bintang",
      "date": "14 Sep 2026"
    },
    {
      "id": "RK-1034",
      "customer": "Joko M.",
      "phone": "085833801412",
      "service": "Joki WR Target 70%",
      "worker": "Rookie_Omega",
      "status": "Pending",
      "progress": "Menunggu Worker",
      "date": "7 Sep 2026"
    },
    {
      "id": "RK-1035",
      "customer": "Sinta W.",
      "phone": "081398296572",
      "service": "Push Mythical Glory 50 Bintang",
      "worker": "Rookie_Spectre",
      "status": "Done",
      "progress": "10/10 Bintang",
      "date": "15 Sep 2026"
    },
    {
      "id": "RK-1036",
      "customer": "Mega H.",
      "phone": "085828890931",
      "service": "Joki Rank Epic to Legend",
      "worker": "Rookie_Viper",
      "status": "Pending",
      "progress": "Menunggu Konfirmasi Pembayaran",
      "date": "13 Sep 2026"
    },
    {
      "id": "RK-1037",
      "customer": "Citra H.",
      "phone": "085800837407",
      "service": "Paket Kilat 5 Bintang",
      "worker": "Rookie_Kaiser",
      "status": "Done",
      "progress": "Selesai 100%",
      "date": "31 Aug 2026"
    },
    {
      "id": "RK-1038",
      "customer": "Wahyu M.",
      "phone": "083114333776",
      "service": "Joki Rank Grandmaster to Epic",
      "worker": "Rookie_Blitz",
      "status": "Done",
      "progress": "5/5 Win",
      "date": "15 Sep 2026"
    },
    {
      "id": "RK-1039",
      "customer": "Gilang H.",
      "phone": "081392544992",
      "service": "Joki Rank Epic to Legend",
      "worker": "Rookie_Blitz",
      "status": "Pending",
      "progress": "Menunggu Konfirmasi Pembayaran",
      "date": "13 Sep 2026"
    },
    {
      "id": "RK-1040",
      "customer": "Putri S.",
      "phone": "083184777183",
      "service": "Push Mythical Glory 50 Bintang",
      "worker": "Rookie_Kaiser",
      "status": "Done",
      "progress": "Selesai 100%",
      "date": "7 Sep 2026"
    },
    {
      "id": "RK-1041",
      "customer": "Wahyu K.",
      "phone": "085874633191",
      "service": "Push Mythic 10 Bintang",
      "worker": "Rookie_Spectre",
      "status": "Done",
      "progress": "5/5 Win",
      "date": "12 Sep 2026"
    },
    {
      "id": "RK-1042",
      "customer": "Lina W.",
      "phone": "081353776020",
      "service": "Joki WR Target 85% Fanny",
      "worker": "Rookie_Nexus",
      "status": "On Process",
      "progress": "5/7 Jam",
      "date": "3 Sep 2026"
    },
    {
      "id": "RK-1043",
      "customer": "Lina S.",
      "phone": "085115055613",
      "service": "Joki Turnamen MRO Piala Biru",
      "worker": "Rookie_Viper",
      "status": "Done",
      "progress": "5/5 Win",
      "date": "8 Sep 2026"
    },
    {
      "id": "RK-1044",
      "customer": "Eka M.",
      "phone": "085269156404",
      "service": "Joki Rank Grandmaster to Epic",
      "worker": "Rookie_Viper",
      "status": "Done",
      "progress": "5/5 Win",
      "date": "27 Aug 2026"
    },
    {
      "id": "RK-1045",
      "customer": "Nanda H.",
      "phone": "083168535606",
      "service": "Push 100 Bintang Mythical Immortal",
      "worker": "Rookie_Alpha",
      "status": "Done",
      "progress": "Selesai 100%",
      "date": "15 Sep 2026"
    },
    {
      "id": "RK-1046",
      "customer": "Hana K.",
      "phone": "082147082276",
      "service": "Joki Placement 10 Match",
      "worker": "Rookie_Apex",
      "status": "On Process",
      "progress": "5/9 Match",
      "date": "27 Aug 2026"
    },
    {
      "id": "RK-1047",
      "customer": "Putri W.",
      "phone": "085786122138",
      "service": "Push 100 Bintang Mythical Immortal",
      "worker": "Rookie_Blitz",
      "status": "Done",
      "progress": "Target Tercapai",
      "date": "6 Sep 2026"
    },
    {
      "id": "RK-1048",
      "customer": "Mega W.",
      "phone": "082183312581",
      "service": "Joki Placement 10 Match",
      "worker": "Rookie_Phantom",
      "status": "On Process",
      "progress": "4/5 Match",
      "date": "3 Sep 2026"
    },
    {
      "id": "RK-1049",
      "customer": "Indra M.",
      "phone": "085836450749",
      "service": "Joki Placement 10 Match",
      "worker": "Rookie_Zeta",
      "status": "Done",
      "progress": "10/10 Bintang",
      "date": "14 Sep 2026"
    },
    {
      "id": "RK-1050",
      "customer": "Citra W.",
      "phone": "085267640206",
      "service": "Joki Turnamen MRO Piala Biru",
      "worker": "Rookie_Blitz",
      "status": "Dibatalkan",
      "progress": "Refund Diproses",
      "date": "16 Sep 2026"
    }
  ],
  "paymentMethods": {
    "qris": {
      "badge": "Otomatis",
      "description": "Scan menggunakan Bank (BCA, Mandiri, BRI, BNI) atau E-Wallet (GoPay, OVO, DANA, ShopeePay).",
      "qrImageUrl": "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=ROOKIEJOKI-QRIS-DEMO",
      "merchantName": "NMK: ROOKIE JOKI OFFICIAL"
    },
    "accounts": [
      {
        "category": "ewallet",
        "label": "GoPay / OVO / DANA",
        "number": "0812-3456-7890",
        "note": ""
      },
      {
        "category": "bank",
        "label": "BCA",
        "number": "8830-1234-5678",
        "note": "a.n. Rookie Joki Official"
      },
      {
        "category": "bank",
        "label": "Mandiri",
        "number": "137-00-1234567-8",
        "note": "a.n. Rookie Joki Official"
      },
      {
        "category": "paylater",
        "label": "SPayLater / ShopeePay",
        "number": "0812-3456-7890",
        "note": ""
      }
    ],
    "buttonLabels": {
      "qris": [
        "QRIS",
        "Instant"
      ],
      "ewallet": [
        "E-Wallet",
        "GoPay/OVO"
      ],
      "bank": [
        "Bank",
        "BCA/Mandiri"
      ],
      "paylater": [
        "PayLater",
        "Shopee"
      ]
    }
  },
  "bottomNav": [
    {
      "label": "Beranda",
      "icon": "home",
      "actionType": "scroll",
      "target": "#beranda",
      "active": true
    },
    {
      "label": "About Us",
      "icon": "gamepad",
      "actionType": "modal",
      "target": "openAboutUsModal",
      "active": false
    },
    {
      "label": "Testimoni",
      "icon": "handshake",
      "actionType": "modal",
      "target": "openTestimonialsModal",
      "active": false
    },
    {
      "label": "Disclaimer",
      "icon": "shield-alert",
      "actionType": "modal",
      "target": "openDisclaimerModal",
      "active": false
    },
    {
      "label": "Blog",
      "icon": "notebook",
      "actionType": "modal",
      "target": "openBlogModal",
      "active": false
    }
  ],
  "faqs": [
    {
      "id": 6,
      "question": "Apakah aman menggunakan jasa joki di Rookie Joki?",
      "answer": "Sangat aman! Kami telah beroperasi sejak 2021 dan dikelola oleh pro player berpengalaman yang mengutamakan kerahasiaan akun serta privasi pelanggan tanpa menggunakan program ilegal atau cheat."
    },
    {
      "id": 7,
      "question": "Berapa lama estimasi pengerjaan orderan joki rank?",
      "answer": "Durasi pengerjaan bervariasi tergantung jumlah bintang atau paket yang dipesan. Rata-rata per 5 bintang hanya membutuhkan waktu beberapa jam hingga 1 hari saja tanpa ada penundaan."
    },
    {
      "id": 4,
      "question": "Bisakah saya request hero tertentu saat proses joki?",
      "answer": "Tentu bisa! Anda bebas merequest hero andalan (role Jungler, Gold Laner, Exp Laner, Mage, atau Roamer) selama hero tersebut terbuka dan dapat digunakan dalam mode rank."
    },
    {
      "id": 8,
      "question": "Bagaimana cara melacak status pengerjaan akun saya?",
      "answer": "Anda dapat menggunakan fitur <strong>Cek Status Pesanan</strong> di bagian atas halaman ini dengan memasukkan ID Transaksi atau nomor WhatsApp Anda, atau langsung menghubungi admin via WhatsApp."
    },
    {
      "id": 9,
      "question": "Metode pembayaran apa saja yang didukung?",
      "answer": "Kami mendukung pembayaran praktis via QRIS (semua e-wallet dan bank), transfer bank langsung (BCA & Mandiri), e-wallet manual (GoPay, OVO, DANA), hingga ShopeePay/SPayLater."
    },
    {
      "id": 10,
      "question": "Apa bedanya Joki Login dan Joki Gendong (Mabar)?",
      "answer": "Joki Login berarti akun Anda dimainkan langsung oleh worker kami. Sedangkan Joki Gendong (Mabar) berarti Anda bermain menggunakan akun sendiri dan didampingi/digendong oleh squad pro player kami."
    },
    {
      "id": 11,
      "question": "Apakah ada jaminan garansi jika mengalami kekalahan (lose)?",
      "answer": "Ya, setiap bintang yang berkurang akibat kekalahan saat dikerjakan worker akan digantikan (kompensasi bintang) hingga target pesanan Anda tercapai sepenuhnya tanpa biaya tambahan."
    },
    {
      "id": 2,
      "question": "Informasi Penting Sebelum Order",
      "answer": "<ul class=\"list-disc pl-4 space-y-1\">\n<li>Matikan Verifikasi Akun untuk Mempermudah worker Login.</li>\n<li>Jika Akun di Login tanpa izin, maka proses Joki akan dibatalkan dan uang pembayaran Anda akan hangus.</li>\n<li>Dimohon menunggu sesuai estimasi proses dan dilarang chat-spam Admin.</li>\n<li>Jika ada problem saat Login ke akun, maka akan segera di hubungi oleh Admin.</li>\n<li>Jika akun belum di proses selama kurang lebih dari 6 jam, harap hubungi Admin.</li>\n<li>Bukti TF akan selalu di verifikasi sebelum Akun diproses.</li>\n<li>Jika proses Joki sudah selesai maka akan segera diinfokan oleh Admin.</li>\n</ul>"
    },
    {
      "id": 1,
      "question": "Bagaimana cara mulai memesan layanan di Rookie Joki?",
      "answer": "Anda cukup memilih paket layanan pada daftar pricelist di atas, klik tombol <strong>Pesan</strong>, atau gunakan Kalkulator Target untuk menghitung biaya, lalu Anda akan diarahkan langsung ke WhatsApp admin kami."
    },
    {
      "id": 3,
      "question": "Format Order Joki",
      "answer": "<ul class=\"list-disc pl-4 space-y-1\">\n<li>Lengkapi Data Login akun Mobile Legends Anda dengan teliti.</li>\n<li>Pilih kategori joki, Rank Eceran, Paketan, Joki Gendong atau MRO.</li>\n<li>Masukkan jumlah Per (Star/Point) yang dituju.</li>\n<li>Masukan No. WhatsApp Anda dengan benar.</li>\n<li>Tunggu Admin menghubungi Anda.</li>\n<li>Admin akan menghubungi untuk Info & Konfirmasi Pembayaran.</li>\n<li>Setelah pembayaran berhasil, akun Anda akan segera di proses.</li>\n<li>Estimasi proses Jasa Joki mulai dari minimal 6 Jam – 2 x 24 Jam (Tergantung Banyaknya Antrian).</li>\n<li>Jika pesanan Anda belum di proses dalam waktu 30 menit, silahkan chat Admin.</li>\n</ul>"
    },
    {
      "id": 5,
      "question": "Maksimal berapa hero yang bisa di joki?",
      "answer": "Request maksimal hero yang boleh di joki sebanyak 3 Hero, lebih dari itu kami tidak melayani."
    },
    {
      "id": 12,
      "question": "Jaringan Internet terputus saat Joki Gendong/Mabar VIP",
      "answer": "Jika saat sedang Joki Gendong/Mabar VIP Jaringan Internet terputus, hal tersebut tidak masalah, karena worker kami anti kalah-kalah klub."
    },
    {
      "id": 13,
      "question": "Apakah MRO bisa di gendong?",
      "answer": "Mohon Maaf, kami tidak menyediakan joki gendong untuk paket MRO."
    }
  ],
  "calculator": {
    "rankOptions": [
      {
        "name": "Warrior",
        "price": 1000,
        "label": "Rp 1.000 / bintang"
      },
      {
        "name": "Elite",
        "price": 1500,
        "label": "Rp 1.500 / bintang"
      },
      {
        "name": "Master",
        "price": 2000,
        "label": "Rp 2.000 / bintang"
      },
      {
        "name": "Grandmaster",
        "price": 3000,
        "label": "Rp 3.000 / bintang"
      },
      {
        "name": "Epic",
        "price": 4000,
        "label": "Rp 4.000 / bintang"
      },
      {
        "name": "Legend",
        "price": 5000,
        "label": "Rp 5.000 / bintang"
      },
      {
        "name": "Mythic",
        "price": 7000,
        "label": "Rp 7.000 / bintang"
      },
      {
        "name": "Mythical Honor",
        "price": 10000,
        "label": "Rp 10.000 / bintang"
      },
      {
        "name": "Mythical Glory",
        "price": 13000,
        "label": "Rp 13.000 / bintang"
      },
      {
        "name": "Mythical Immortal",
        "price": 18000,
        "label": "Rp 18.000 / bintang"
      }
    ],
    "defaultStars": 5,
    "maxStars": 100
  },
  "admins": [
    {
      "id": 1,
      "username": "admin",
      "passwordHash": "4671037693915bc095fb26f7f6a01ea665b38c76c429bfeaf1a3db5f700e712d"
    }
  ],
  "search": {
    "placeholder": "Cari paket joki, rank, atau layanan..."
  }
};
